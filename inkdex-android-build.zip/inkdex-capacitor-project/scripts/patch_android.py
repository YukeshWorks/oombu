#!/usr/bin/env python3
"""Apply small Android wrapper settings after `npx cap add android`/`cap sync`."""
from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
manifest = root / "android/app/src/main/AndroidManifest.xml"
if not manifest.exists():
    raise SystemExit("AndroidManifest.xml missing: run `npx cap add android` first")

text = manifest.read_text(encoding="utf-8")
android_ns = "http://schemas.android.com/apk/res/android"
if "android.permission.INTERNET" not in text:
    text = re.sub(r"(<manifest\b[^>]*>)", r'\1\n    <uses-permission android:name="android.permission.INTERNET" />', text, count=1)
# Do not lock the Android Activity to portrait; allow sensor rotation.
text = re.sub(r'android:screenOrientation="[^"]+"', 'android:screenOrientation="unspecified"', text)
manifest.write_text(text, encoding="utf-8")

# Capacitor's theme filename can vary slightly between template revisions. Patch
# any AppTheme styles that exist; Android 15+ may still draw system bars edge-to-edge.
res = root / "android/app/src/main/res"
patched = 0
for file in list(res.glob("values*/styles.xml")) + list(res.glob("values*/themes.xml")):
    source = file.read_text(encoding="utf-8")
    def update_style(match):
        nonlocal_dummy = None
        opening, body, closing = match.group(1), match.group(2), match.group(3)
        if "AppTheme" not in opening:
            return match.group(0)
        items = {
            "android:statusBarColor": "#080a16",
            "android:navigationBarColor": "#080a16",
            "android:windowLightStatusBar": "false",
            "android:windowLightNavigationBar": "false"
        }
        for name, value in items.items():
            if f'name="{name}"' not in body:
                body += f'\n        <item name="{name}">{value}</item>'
        return opening + body + closing
    updated = re.sub(r'(<style\b[^>]*name=["\'][^"\']*AppTheme[^"\']*["\'][^>]*>)(.*?)(</style>)', update_style, source, flags=re.S)
    if updated != source:
        file.write_text(updated, encoding="utf-8")
        patched += 1
print(f"Manifest checked; patched {patched} Android theme file(s).")
