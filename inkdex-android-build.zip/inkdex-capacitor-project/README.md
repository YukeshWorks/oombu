# Inkdex Android APK build

This project packages the supplied Inkdex PWA in a Capacitor Android WebView. The PDF search/AI JavaScript source has been copied as supplied; no search/indexing logic was intentionally changed. The PWA manifest orientation metadata is set to `any` so both portrait and landscape are permitted.

## Build a downloadable APK with GitHub Actions

1. Extract this folder on your PC.
2. Create a **new empty GitHub repository** (private is fine). Do not add a README or `.gitignore` on GitHub.
3. Open PowerShell or Terminal in this extracted project folder and run (replace the URL with your own repo URL):

   ```bash
   git init
   git add .
   git commit -m "Prepare Inkdex Android APK build"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/inkdex-android.git
   git push -u origin main
   ```

4. In that GitHub repository, open **Actions** and select **Build Inkdex Android APK**. The first push starts it automatically. Wait for the run to finish with a green check.
5. Open the completed run, find **Artifacts**, and download **inkdex-debug-apk**. The downloaded ZIP contains `inkdex.apk`.
6. Transfer `inkdex.apk` to your Android phone. In Settings, allow the file manager/browser you use to **Install unknown apps**, open the APK, and install Inkdex.
7. Open Inkdex, go to **Library** and add PDFs. Open the **AI** tab and download MiniLM for semantic search.

## Local Windows build (alternative)

Install Node.js 22+, Android Studio 2025.2.1 or later, and Android SDK Platform 36 / Build Tools 36.0.0. Then run in PowerShell from this folder:

```powershell
npm install
npx cap add android
npx capacitor-assets generate --android --iconBackgroundColor '#080a16' --splashBackgroundColor '#080a16'
npx cap sync android
python scripts/patch_android.py
cd android
.\gradlew.bat assembleDebug
Copy-Item .\app\build\outputs\apk\debug\app-debug.apk ..\inkdex.apk
```

The APK is a **debug-signed sideload build**, not a Play Store release. A later update must be signed with the same key or Android may refuse it as an update.

## Android wrapper choices

- App name: `Inkdex`; application ID: `com.yukeshworks.inkdex`.
- Local WebView scheme: HTTPS (`https://localhost`) so secure-context browser APIs and service workers can operate.
- The web asset bundle includes the original service worker, IndexedDB/Cache API use, module workers, PDF.js and ONNX Runtime WASM files.
- No domain allowlist or custom network-security block is added; model fetches to Hugging Face remain ordinary HTTPS fetches. Internet permission is ensured in the Android manifest.
- PDF selection uses the app's existing `<input type="file">`; no broad storage permission is requested.
- Launcher/splash assets are generated from the supplied app icon on build.

## Validation status

The ZIP was inspected and the wrapper/build files were prepared. This environment did **not** have an Android SDK or Gradle installation and could not reach the npm registry, so an APK could not be compiled or installed here. The GitHub Actions workflow has not been run from this environment. The resulting APK therefore still needs a successful Actions build and a real-device smoke test on the target phone. In particular, verify PDF picking, service-worker persistence, MiniLM download/inference, large-PDF indexing, and wake-lock behaviour on-device.
