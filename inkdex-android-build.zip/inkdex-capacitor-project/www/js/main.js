// Inkdex: UI and orchestration.
import * as store from './store.js';
import {Engine} from './engine.js';
import {Indexer,docRecord} from './indexer.js';
import {EMBED_MODELS,CHAT_MODELS,Embedder,Chat,hasWebGPU,cachedFiles,removeCached,progressTracker,storageInfo} from './ai.js';
import {esc,fmtSize,clean,hiRegex,hiHTML,snippet,sectionOf,tick,SURF} from './textproc.js';

const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
let toastT;function toast(m){const t=$('#toast');t.textContent=m;t.classList.add('show');clearTimeout(toastT);toastT=setTimeout(()=>t.classList.remove('show'),2800)}
const buzz=()=>{try{navigator.vibrate&&navigator.vibrate(8)}catch(e){}};
const lsGet=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))??d}catch(e){return d}};
const lsSet=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}};
const throttle=(fn,ms)=>{let t=0,p=null;return()=>{const n=performance.now();if(n-t>=ms){t=n;fn()}else if(!p){p=setTimeout(()=>{p=null;t=performance.now();fn()},ms-(n-t))}}};
const mins=s=>s<90?'about a minute':s<5400?Math.round(s/60)+' min':(s/3600).toFixed(1)+' h';

/* ---------------- test hook: ?localmodels=/models/ adds a tiny local model ---------------- */
const LOCAL=new URLSearchParams(location.search).get('localmodels');
if(LOCAL)EMBED_MODELS.unshift({id:'tiny',hf:'local/tiny-embed',name:'Test model',tag:'developer test',mb:1,dtype:'fp32',qp:'',pp:'',floor:0,rel:.5,note:'Developer test model (random weights).'});

/* ---------------- state ---------------- */
const engine=new Engine(),ai={embedder:new Embedder(),chat:new Chat()};
const DEF={embId:'minilm',mode:'fast',keepCopies:true,gpuEmbed:false,chatId:'qwen05',paused:false,ready:{embed:{},chat:{}}};
let S=JSON.parse(JSON.stringify(DEF));
const embModel=()=>EMBED_MODELS.find(m=>m.id===S.embId)||EMBED_MODELS[0];
const chatModel=()=>CHAT_MODELS.find(m=>m.id===S.chatId)||CHAT_MODELS[0];
const saveSettings=()=>store.put('meta','settings',S).catch(()=>{});
const idx=new Indexer(engine,ai,()=>({model:embModel(),mode:S.mode,keepCopies:S.keepCopies,paused:S.paused}));
const MS={embed:{},chat:{}};const ms=(k,id)=>MS[k][id]||(MS[k][id]={state:S.ready[k][id]?'ready':'idle',pct:0});
let scope='all',headOnly=false,libShown=50,libQ='',deferredInstall=null,storage={usage:0,quota:0,persisted:false};

/* ---------------- text cache ---------------- */
const textCache=new Map();
async function docTexts(id){
  if(textCache.has(id)){const v=textCache.get(id);textCache.delete(id);textCache.set(id,v);return v}
  const t=(await store.get('texts',id))||[];textCache.set(id,t);if(textCache.size>40)textCache.delete(textCache.keys().next().value);return t;
}
const textOf=async(d,p)=>(await docTexts(d.id))[p-1];
function bodyOf(doc,p,texts){const hs=new Set(doc.heads.filter(h=>h.p===p).map(h=>h.t));const t=texts[p-1]||'';const kept=t.split('\n').filter(l=>!hs.has(l.trim())).join(' ');return kept.trim()?kept:t}

/* ---------------- boot ---------------- */
const setBoot=(m,p)=>{$('#bootmsg').textContent=m;if(p!=null)$('#bootbar').style.width=Math.max(6,Math.round(p*100))+'%'};
async function boot(){
  try{await store.open()}catch(e){setBoot('This browser blocked storage, so Inkdex cannot save your library. Open it in Chrome and allow site data.');return}
  try{const s=await store.get('meta','settings');if(s)S={...DEF,...s,ready:{embed:{...(s.ready&&s.ready.embed)},chat:{...(s.ready&&s.ready.chat)}}}}catch(e){}
  if(LOCAL&&!S.ready.embed.tiny){S.embId='tiny'}
  const t0=performance.now();
  await idx.reload(p=>setBoot('Loading your library…',p));
  window.__loadMs=performance.now()-t0;
  idx.onchange=onIndexChange;
  renderAll();
  $('#boot').classList.add('gone');setTimeout(()=>$('#boot').remove(),500);
  restoreModels();
  refreshStorage();
  if('serviceWorker' in navigator)navigator.serviceWorker.register('sw.js').catch(()=>{});
  if(!/Android/i.test(navigator.userAgent)&&'webkitdirectory' in document.createElement('input'))$('#folderbtn').hidden=false;
  initVoice();
}
function renderAll(){renderStats();renderScopes();renderLib();renderProgress();home();renderSemLine();renderAI();updateAskChips();renderAskState();chatEmpty()}

/* ---------------- header + status ---------------- */
function renderStats(){const n=engine.docs.length;$('#stats').textContent=n?`${n.toLocaleString()} ${n===1?'doc':'docs'} · ${engine.nPages.toLocaleString()} pages`:'No documents yet'}
$('#stats').onclick=()=>showTab(engine.docs.length?'lib':'lib');
function renderScopes(){
  const docs=[...engine.docs].sort((a,b)=>a.name.localeCompare(b.name));
  const opts='<option value="all">All documents</option>'+docs.map(d=>`<option value="${d.id}">${esc(d.name.replace(/\.pdf$/i,''))}</option>`).join('');
  for(const s of [$('#scope'),$('#askscope')]){const v=s.value;s.innerHTML=opts;s.value=docs.some(d=>d.id===v)?v:'all'}
  scope=$('#scope').value;updateAskChips();
}

/* ---------------- search ---------------- */
const $q=$('#q');let seq=0,semTimer,aiTerms=new Map();const qvecCache=new Map();
const semanticReady=()=>engine.vec.n>0&&ai.embedder.ready&&ai.embedder.model.id===embModel().id;
async function queryVec(q){
  if(qvecCache.has(q))return qvecCache.get(q);
  const r=await ai.embedder.embed([q],'query');const v=Float32Array.from(r.data.subarray(0,r.dim));
  qvecCache.set(q,v);if(qvecCache.size>40)qvecCache.delete(qvecCache.keys().next().value);return v;
}
function home(){
  if($q.value.trim())return;
  const docs=engine.docs;if(!docs.length){$('#results').innerHTML='<div class="empty"><b>Your library is empty.</b><br>Open the Library tab and add your PDFs. Each one is read once, then searching is instant.</div>';return}
  const cnt=new Map();docs.forEach(d=>(d.topics||[]).slice(0,5).forEach(t=>cnt.set(t,(cnt.get(t)||0)+1)));
  const topics=[...cnt].sort((a,b)=>b[1]-a[1]).slice(0,18).map(x=>x[0]);
  const recent=lsGet('inkdex-recent',[]);
  const heads=[];[...docs].sort((a,b)=>b.added-a.added).slice(0,8).forEach(d=>d.heads.filter(h=>h.l===1).slice(0,2).forEach(h=>heads.push({d,h})));
  let h='';
  if(recent.length)h+='<div class="h2">Recent searches</div><div class="row">'+recent.map(r=>`<button class="chip" data-q="${esc(r)}">${esc(r)}</button>`).join('')+'</div>';
  if(topics.length)h+='<div class="h2">Browse by topic</div><div class="row">'+topics.map(t=>`<button class="chip" data-q="${esc(t)}">${esc(t)}</button>`).join('')+'</div>';
  if(heads.length)h+='<div class="h2">Jump to a heading</div>'+heads.slice(0,12).map(x=>`<button class="hrow" data-doc="${x.d.id}" data-p="${x.h.p}"><b>${esc(x.h.t)}</b><small>${esc(x.d.name.replace(/\.pdf$/i,'').slice(0,26))} · p.${x.h.p}</small></button>`).join('');
  $('#results').innerHTML=h;
}
function renderSemLine(){
  const el=$('#semline');if(!engine.docs.length){el.innerHTML='';return}
  const m=embModel(),pct=Math.round(idx.embedProgress()*100);
  if(!S.ready.embed[m.id])el.innerHTML='Keyword search only. <button class="chip sm" data-go="ai">Add meaning search</button>';
  else if(!ai.embedder.ready)el.innerHTML='<b>Meaning search</b> is starting…';
  else if(engine.vec.n===0)el.innerHTML='<b>Meaning search</b> is learning your library · '+pct+'%';
  else el.innerHTML=`<b>Meaning search on</b> · ${pct}% of your library understood${pct<100&&!S.paused?' and growing':''}`;
}
async function runSearch(){
  const q=$q.value.trim(),my=++seq;clearTimeout(semTimer);
  if(!q){home();return}
  const t0=performance.now();
  const opts={docId:scope,headOnly,extra:aiTerms.get(q)||[],textOf};
  const res=await engine.search(q,{...opts,qvec:null});if(my!==seq)return;
  await renderResults(res,q,performance.now()-t0);
  if(semanticReady()&&!headOnly&&q.length>=2){
    semTimer=setTimeout(async()=>{
      try{
        const t1=performance.now(),qv=await queryVec(q);if(my!==seq)return;
        const m=embModel(),r2=await engine.search(q,{...opts,qvec:qv,floor:m.floor,rel:m.rel});if(my!==seq)return;
        await renderResults(r2,q,performance.now()-t1);
      }catch(e){}
    },260);
  }
}
let lastRoots=[];
async function renderResults(res,q,msTook){
  const box=$('#results');
  if(!res||!res.hits.length){box.innerHTML=`<div class="empty"><b>No pages match “${esc(q)}”.</b><br>Try fewer words or different wording.${semanticReady()?'':' Add meaning search in the AI tab to find pages by what they are about.'}</div>`;return}
  lastRoots=res.roots;
  const shown=res.hits.slice(0,25);await Promise.all(shown.map(g=>docTexts(g.doc.id)));
  const re=hiRegex(res.roots);
  let h=`<div class="stat">${res.nPages} ${res.nPages===1?'page':'pages'} in ${res.hits.length} ${res.hits.length===1?'document':'documents'} · ${msTook<1?'<1':Math.round(msTook)} ms${res.semUsed?' · meaning on':''}</div>`;
  h+=shown.map((g,gi)=>{
    const texts=textCache.get(g.doc.id)||[];
    const hits=g.pages.slice(0,3).map(pg=>{
      const sec=sectionOf(g.doc,pg.p),raw=texts[pg.p-1]||'';let snip;
      if(pg.kw||pg.chunk<0)snip=snippet(bodyOf(g.doc,pg.p,texts),re);
      else{const v=engine.vec,t=clean(raw),piece=t.slice(v.cstart[pg.chunk],v.cend[pg.chunk]);snip=esc(piece.slice(0,260))+(piece.length>260?' …':'')}
      return `<button class="hit" data-doc="${g.doc.id}" data-p="${pg.p}"><div class="meta"><span>Page ${pg.p}</span>${sec?`<span class="sec">${esc(sec)}</span>`:''}${pg.sem&&!pg.kw?'<span class="tag">meaning</span>':''}</div><p>${snip}</p></button>`;
    }).join('');
    const more=g.pages.length>3?`<div class="more">+ ${g.pages.length-3} more matching ${g.pages.length-3===1?'page':'pages'}</div>`:'';
    return `<div class="card" style="animation-delay:${Math.min(gi,8)*35}ms"><div class="dh"><div class="ic"><svg class="i"><use href="#i-doc"/></svg></div><div><b>${esc(g.doc.name.replace(/\.pdf$/i,''))}</b><small>${g.doc.n} pages</small></div></div><div class="bar"><i style="width:${Math.max(8,Math.round(100*g.score/res.top))}%"></i></div>${hits}${more}</div>`;
  }).join('');
  if(res.hits.length>25)h+=`<div class="more">Showing the best 25 of ${res.hits.length} documents. Narrow the search to see others.</div>`;
  box.innerHTML=h;
}
let qT;function onInput(now){$('#qclear').hidden=!$q.value;clearTimeout(qT);qT=setTimeout(runSearch,now?0:90)}
const remember=q=>{q=q.trim();if(!q)return;const r=lsGet('inkdex-recent',[]).filter(x=>x!==q);r.unshift(q);lsSet('inkdex-recent',r.slice(0,8))};
$q.addEventListener('input',()=>onInput(false));
$q.addEventListener('keydown',e=>{if(e.key==='Enter'){remember($q.value);onInput(true);$q.blur()}});
$('#qclear').onclick=()=>{$q.value='';onInput(true);$q.focus()};
$('#scope').onchange=e=>{scope=e.target.value;onInput(true)};
$('#headonly').onclick=e=>{headOnly=!headOnly;e.currentTarget.classList.toggle('on',headOnly);onInput(true)};
document.addEventListener('click',e=>{const g=e.target.closest('[data-go]');if(g)showTab(g.dataset.go)});
$('#results').addEventListener('click',e=>{
  const c=e.target.closest('[data-q]');if(c){$q.value=c.dataset.q;remember(c.dataset.q);onInput(true);return}
  const h=e.target.closest('[data-doc]');if(h)openViewer(h.dataset.doc,+h.dataset.p);
});
function initVoice(){
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR)return;
  const mic=$('#mic');mic.hidden=false;let rec=null;
  mic.onclick=()=>{
    if(rec){rec.stop();return}
    rec=new SR();rec.lang=navigator.language||'en-IN';rec.interimResults=true;rec.maxAlternatives=1;
    mic.classList.add('live');
    rec.onresult=e=>{let t='';for(const r of e.results)t+=r[0].transcript;$q.value=t;onInput(false)};
    rec.onend=()=>{mic.classList.remove('live');rec=null;onInput(true)};
    rec.onerror=()=>{mic.classList.remove('live');rec=null};
    try{rec.start()}catch(e){rec=null;mic.classList.remove('live')}
  };
}

/* ---------------- tabs ---------------- */
function showTab(name){
  $$('nav button').forEach(b=>b.classList.toggle('on',b.dataset.tab===name));
  $$('.tab').forEach(t=>t.classList.toggle('on',t.id==='tab-'+name));
  if(name==='ask')setTimeout(()=>{const c=$('#chat');c.scrollTop=c.scrollHeight},0);
  if(name==='ai')refreshStorage();
}
$$('nav button').forEach(b=>b.onclick=()=>{showTab(b.dataset.tab);buzz()});

/* ---------------- library ---------------- */
function renderLib(){
  const all=[...engine.docs].sort((a,b)=>b.added-a.added);
  const fq=libQ.toLowerCase(),docs=fq?all.filter(d=>d.name.toLowerCase().includes(fq)):all;
  $('#libfilter').hidden=all.length<8;
  const vk=idx.vkey();
  let h=docs.slice(0,libShown).map(d=>{
    const chips=(d.topics||[]).slice(0,4).map(t=>`<span class="chip sm">${esc(t)}</span>`).join('');
    const tag=d.vkey===vk?'<span class="tag ok">AI ready</span>':'<span class="tag warn">keyword</span>';
    return `<div class="card tap" data-id="${d.id}"><div class="dh"><div class="ic"><svg class="i"><use href="#i-doc"/></svg></div><div><b>${esc(d.name.replace(/\.pdf$/i,''))}</b><small>${d.n} pages · ${d.heads.length} headings · ${fmtSize(d.size)}${d.scanned.length?' · '+d.scanned.length+' pages without text':''}</small></div></div><div class="row" style="margin:0">${tag}${chips}</div></div>`;
  }).join('');
  if(docs.length>libShown)h+=`<button class="btn ghost" id="libmore" style="width:100%">Show ${Math.min(50,docs.length-libShown)} more (${docs.length-libShown} left)</button>`;
  if(!docs.length)h=all.length?'<div class="empty">No file names match.</div>':'';
  $('#liblist').innerHTML=h;
}
$('#liblist').addEventListener('click',e=>{
  if(e.target.closest('#libmore')){libShown+=50;renderLib();return}
  const c=e.target.closest('[data-id]');if(c)openDocSheet(c.dataset.id);
});
$('#libfilter').addEventListener('input',e=>{libQ=e.target.value.trim();libShown=50;renderLib()});
async function ask2persist(){try{if(navigator.storage&&navigator.storage.persist&&!(await navigator.storage.persisted()))await navigator.storage.persist()}catch(e){}refreshStorage()}
async function addFiles(files){
  if(!files||!files.length)return;
  idx.resetReadStats();ask2persist();
  const p=idx.addFiles(files);renderProgress();
  const r=await p;if(r&&r.added===0&&r.skipped===0&&!idx.read.total)toast('Choose PDF files.');
}
$('#file').onchange=e=>{addFiles(e.target.files);e.target.value=''};
$('#folder').onchange=e=>{addFiles(e.target.files);e.target.value=''};
const drop=$('#drop');
['dragover','dragenter'].forEach(ev=>drop.addEventListener(ev,e=>{e.preventDefault();drop.classList.add('over')}));
['dragleave','drop'].forEach(ev=>drop.addEventListener(ev,e=>{e.preventDefault();drop.classList.remove('over')}));
drop.addEventListener('drop',e=>{if(e.dataTransfer&&e.dataTransfer.files)addFiles(e.dataTransfer.files)});

function renderProgress(){
  const r=idx.read,em=idx.emb,m=embModel();let h='';
  if(r.total>0){
    const pct=Math.round(100*r.done/r.total);
    h+=`<div class="card"><div class="dh"><div class="ic"><svg class="i"><use href="#i-doc"/></svg></div><div><b>${r.active?'Reading your PDFs':'Reading finished'}</b><small>${r.done.toLocaleString()} of ${r.total.toLocaleString()}${r.skipped?` · ${r.skipped} already in library`:''}${r.active&&r.cur?' · '+esc(r.cur.slice(0,34)):''}</small></div></div><div class="bar"><i style="width:${pct}%"></i></div>`;
    if(r.failed.length)h+=`<details class="fails"><summary>${r.failed.length} could not be read</summary>${r.failed.slice(0,60).map(f=>`<div>${esc(f.name)}: ${esc(f.why)}</div>`).join('')}</details>`;
    if(!r.active)h+=`<div class="row" style="margin-bottom:0"><button class="btn sm ghost" data-do="dismissread">Dismiss</button></div>`;
    h+='</div>';
  }
  if(engine.docs.length){
    if(S.ready.embed[m.id]&&ai.embedder.ready){
      const pct=Math.round(idx.embedProgress()*100),pend=idx.pendingDocs().length;
      let line=em.err?`Stopped: ${esc(em.err)}`:S.paused?'Paused. Your keyword search still works.':em.active?`Building the meaning index${em.rate?` · about ${mins(idx.eta())} left`:''}`:pend?'Waiting to continue':'Every document is understood';
      h+=`<div class="card"><div class="dh"><div class="ic"><svg class="i"><use href="#i-spark"/></svg></div><div><b>AI meaning index · ${pct}%</b><small>${line}</small></div></div><div class="bar"><i style="width:${pct}%"></i></div>`;
      if(pend||S.paused)h+=`<div class="row" style="margin-bottom:0"><button class="btn sm ghost" data-do="${S.paused?'resume':'pause'}"><svg class="i" style="width:16px;height:16px"><use href="#i-${S.paused?'play':'pause'}"/></svg>${S.paused?'Resume':'Pause'}</button>${em.err?'<button class="btn sm" data-do="resume">Retry</button>':''}</div>`;
      if(pend&&!S.paused)h+='<p class="sub" style="margin:10px 0 0">Keep the screen on and the phone charging while the first index builds. If you close the app it continues from where it stopped.</p>';
      h+='</div>';
    }else if(S.ready.embed[m.id]){
      h+=`<div class="card"><div class="dh"><div class="ic"><svg class="i"><use href="#i-spark"/></svg></div><div><b>AI meaning index</b><small>Starting the search brain…</small></div></div></div>`;
    }else{
      h+=`<div class="card"><div class="dh"><div class="ic"><svg class="i"><use href="#i-spark"/></svg></div><div><b>Meaning search is off</b><small>Download the search brain once (${m.mb} MB) and Inkdex will understand every page, like Google Photos search.</small></div></div><button class="btn sm" data-go="ai">Open AI downloads</button></div>`;
    }
  }
  $('#prog').innerHTML=h;
}
$('#prog').addEventListener('click',e=>{
  const d=e.target.closest('[data-do]');if(!d)return;
  if(d.dataset.do==='dismissread'){idx.read={active:false,total:0,done:0,skipped:0,failed:[],cur:''};renderProgress()}
  if(d.dataset.do==='pause'){S.paused=true;saveSettings();renderProgress();renderAI()}
  if(d.dataset.do==='resume'){S.paused=false;idx.emb.err='';saveSettings();idx.kickEmbed();renderProgress();renderAI()}
});
let lastDocCount=-1,libTimer;
let wasEmbedding=false;
function onIndexChange(){
  renderProgress();renderStats();renderSemLine();renderAIThrottled();
  if(wasEmbedding!==idx.emb.active){wasEmbedding=idx.emb.active;renderLib()}
  if(engine.docs.length!==lastDocCount){lastDocCount=engine.docs.length;clearTimeout(libTimer);libTimer=setTimeout(()=>{renderLib();renderScopes();home();updateAskChips()},700)}
}
// refresh the library cards when AI tags change
setInterval(()=>{if(idx.emb.active)renderLib()},8000);

/* ---------------- doc sheet ---------------- */
function openSheet(el){el.classList.add('open');try{location.hash=el.id==='viewer'?'reader':'details'}catch(e){}}
function closeSheet(el){el.classList.remove('open');try{if(location.hash)history.replaceState(null,'',location.pathname+location.search)}catch(e){}}
window.addEventListener('hashchange',()=>{if(!location.hash)$$('.sheet.open').forEach(s=>s.classList.remove('open'))});
$('#dclose').onclick=()=>closeSheet($('#docsheet'));$('#vclose').onclick=()=>closeSheet($('#viewer'));
function openDocSheet(id){
  const d=engine.byId.get(id);if(!d)return;
  const heads=d.heads.map(h=>`<button class="hrow" data-doc="${d.id}" data-p="${h.p}" style="padding-left:${(h.l-1)*14+4}px"><b>${esc(h.t)}</b><small>p.${h.p}</small></button>`).join('')||'<div class="more">No headings were detected. Search still reads every page.</div>';
  $('#dbody').innerHTML=`<h3>${esc(d.name.replace(/\.pdf$/i,''))}</h3><div class="more">${d.n} pages · ${fmtSize(d.size)}${d.hasFile?'':' · original file not stored (text view only)'}</div>
  <div class="acts"><button class="btn" data-a="open"><svg class="i"><use href="#i-doc"/></svg>Open</button><button class="btn ghost" data-a="ask"><svg class="i"><use href="#i-spark"/></svg>Ask AI</button><button class="btn danger" data-a="del"><svg class="i"><use href="#i-trash"/></svg><span>Delete</span></button></div>
  ${d.scanned.length?`<div class="notice">${d.scanned.length} ${d.scanned.length===1?'page has':'pages have'} no selectable text (scans or images), so ${d.scanned.length===1?'it is':'they are'} not searchable yet.</div>`:''}
  ${(d.topics||[]).length?`<div class="h2">Topics</div><div class="row">${d.topics.map(t=>`<button class="chip" data-t="${esc(t)}">${esc(t)}</button>`).join('')}</div>`:''}
  <div class="h2">Contents</div>${heads}`;
  $('#dbody').dataset.id=id;openSheet($('#docsheet'));
}
$('#dbody').addEventListener('click',async e=>{
  const id=$('#dbody').dataset.id,d=engine.byId.get(id);
  const t=e.target.closest('[data-t]');if(t){closeSheet($('#docsheet'));showTab('search');$q.value=t.dataset.t;$('#scope').value=id;scope=id;onInput(true);return}
  const h=e.target.closest('.hrow[data-doc]');if(h){openViewer(h.dataset.doc,+h.dataset.p);return}
  const a=e.target.closest('[data-a]');if(!a||!d)return;
  if(a.dataset.a==='open')openViewer(id,1);
  if(a.dataset.a==='ask'){closeSheet($('#docsheet'));$('#askscope').value=id;showTab('ask');updateAskChips()}
  if(a.dataset.a==='del'){
    if(a.dataset.sure!=='1'){a.dataset.sure='1';a.querySelector('span').textContent='Tap again to delete';setTimeout(()=>{a.dataset.sure='';const s=a.querySelector('span');if(s)s.textContent='Delete'},3000);return}
    closeSheet($('#docsheet'));toast('Deleting…');textCache.delete(id);pdfCache.delete(id);
    await idx.removeDoc(id);renderAll();toast('Deleted.');idx.e.saveSnapshot().catch(()=>{});
  }
});

/* ---------------- reader ---------------- */
const pdfCache=new Map();let V={doc:null,p:1,mode:'page',roots:[],token:null,task:null,hasFile:false};
async function getPdf(doc){
  if(pdfCache.has(doc.id))return pdfCache.get(doc.id);
  const blob=await store.get('files',doc.id);if(!blob)return null;
  const pdf=await pdfjsLib.getDocument({data:new Uint8Array(await blob.arrayBuffer())}).promise;
  pdfCache.set(doc.id,pdf);if(pdfCache.size>3){const k=pdfCache.keys().next().value;try{await pdfCache.get(k).destroy()}catch(e){}pdfCache.delete(k)}
  return pdf;
}
async function openViewer(id,p,roots){
  const doc=engine.byId.get(id);if(!doc)return;
  V={doc,p:Math.min(Math.max(1,p||1),doc.n),mode:doc.hasFile?'page':'text',roots:roots||lastRoots,token:null,task:null};
  $('#vtitle').textContent=doc.name.replace(/\.pdf$/i,'');$('#vseg').hidden=!doc.hasFile;
  openSheet($('#viewer'));await renderPage();
}
async function renderPage(){
  const {doc,p}=V;$('#vpg').textContent=`Page ${p} / ${doc.n}`;$('#vprev').disabled=p<=1;$('#vnext').disabled=p>=doc.n;
  $('#vsub').textContent=sectionOf(doc,p);$$('#vseg button').forEach(b=>b.classList.toggle('on',b.dataset.m===V.mode));
  const texts=await docTexts(doc.id),txt=texts[p-1]||'',re=hiRegex(V.roots),heads=new Set(doc.heads.filter(h=>h.p===p).map(h=>h.t));
  $('#vtext').innerHTML=txt?txt.split('\n').map(l=>{const b=hiHTML(l,re);return heads.has(l.trim())?`<span class="hd">${b}</span>`:b}).join('\n'):'<span style="color:var(--mute)">This page has no selectable text. It may be a scan or an image.</span>';
  const showCanvas=V.mode==='page'&&doc.hasFile;$('#vcanvas').hidden=!showCanvas;$('#vtext').hidden=showCanvas;$('#vbody').scrollTop=0;
  if(!showCanvas)return;
  const my=Symbol();V.token=my;
  try{
    const pdf=await getPdf(doc);if(!pdf){V.mode='text';renderPage();return}if(V.token!==my)return;
    const page=await pdf.getPage(p),cw=Math.min($('#vbody').clientWidth-24,900),base=page.getViewport({scale:1});
    const dpr=Math.min(window.devicePixelRatio||1,2.5),vp=page.getViewport({scale:cw/base.width*dpr});
    const c=$('#vcanvas');c.width=Math.floor(vp.width);c.height=Math.floor(vp.height);c.style.width=cw+'px';c.style.height=(vp.height/dpr)+'px';
    const ctx=c.getContext('2d');if(V.task){try{V.task.cancel()}catch(e){}}
    V.task=page.render({canvasContext:ctx,viewport:vp});await V.task.promise;if(V.token!==my)return;
    if(re){
      const tc=await page.getTextContent();ctx.fillStyle='rgba(255,95,162,.42)';const mc=document.createElement('canvas').getContext('2d');
      for(const it of tc.items){
        if(!it.str||Math.abs(it.transform[1])>.01)continue;const r=new RegExp(re.source,'giu');let m;
        mc.font='100px '+((tc.styles[it.fontName]&&tc.styles[it.fontName].fontFamily)||'sans-serif');const full=mc.measureText(it.str).width||1;
        while((m=r.exec(it.str))){
          if(m[0]==='')break;const px=i=>it.width*(mc.measureText(it.str.slice(0,i)).width/full);
          const x0=it.transform[4]+px(m.index),x1=it.transform[4]+px(m.index+m[0].length),y=it.transform[5],h=Math.hypot(it.transform[2],it.transform[3])||it.height;
          const a=vp.convertToViewportPoint(x0,y-h*.2),b=vp.convertToViewportPoint(x1,y+h*.85);
          ctx.fillRect(Math.min(a[0],b[0]),Math.min(a[1],b[1]),Math.abs(b[0]-a[0]),Math.abs(b[1]-a[1]));
        }
      }
    }
  }catch(e){if(e&&e.name==='RenderingCancelledException')return;V.mode='text';$('#vcanvas').hidden=true;$('#vtext').hidden=false;toast('Could not draw this page. Showing its text instead.')}
}
$('#vprev').onclick=()=>{if(V.p>1){V.p--;renderPage()}};
$('#vnext').onclick=()=>{if(V.p<V.doc.n){V.p++;renderPage()}};
$('#vseg').addEventListener('click',e=>{const b=e.target.closest('button');if(b){V.mode=b.dataset.m;renderPage()}});
let tx0=null;$('#vbody').addEventListener('touchstart',e=>{tx0=e.touches.length===1?e.touches[0].clientX:null},{passive:true});
$('#vbody').addEventListener('touchend',e=>{if(tx0===null)return;const dx=e.changedTouches[0].clientX-tx0;tx0=null;const b=$('#vbody');if(Math.abs(dx)>90&&b.scrollWidth<=b.clientWidth+4){if(dx<0&&V.p<V.doc.n){V.p++;renderPage()}else if(dx>0&&V.p>1){V.p--;renderPage()}}});

/* ---------------- AI tab: downloads and settings ---------------- */
const friendly=e=>{const m=String(e&&e.message||e);
  if(/Failed to fetch|NetworkError|Load failed|network/i.test(m))return 'Could not reach the model host. Check your internet connection and try again.';
  if(/404|not found|Could not locate|Unauthorized|401|403/i.test(m))return 'The model files were not found at the source.';
  if(/memory|allocation|OOM|out of/i.test(m))return 'Not enough free memory for this model. Close other apps or pick a smaller one.';
  return m.slice(0,160)};
async function restoreModels(){
  for(const m of EMBED_MODELS){if(S.ready.embed[m.id]&&!LOCAL&&!(await cachedFiles(m.hf)))S.ready.embed[m.id]=false}
  for(const m of CHAT_MODELS){if(S.ready.chat[m.id]&&!(await cachedFiles(m.hf)))S.ready.chat[m.id]=false}
  saveSettings();
  const m=embModel();
  if(S.ready.embed[m.id])loadEmbedder(m,true);else renderAll();
}
async function loadEmbedder(model,fromCache){
  const st=ms('embed',model.id);st.state=fromCache?'loading':'downloading';st.pct=0;st.err='';
  ai.embedder.onprogress=progressTracker((pct,l,t)=>{st.pct=pct;st.loaded=l;st.total=t;renderAIThrottled()});
  renderAI();renderProgress();
  try{
    await ai.embedder.load(model,{device:S.gpuEmbed&&hasWebGPU()?'webgpu':'wasm',local:LOCAL});
    S.ready.embed[model.id]=true;saveSettings();st.state='ready';
  }catch(e){st.state='error';st.err=friendly(e);if(fromCache)S.ready.embed[model.id]=false}
  renderAll();
  if(st.state==='ready'){idx.kickEmbed();if($q.value.trim())runSearch()}
}
async function activateEmbed(m){
  const changed=S.embId!==m.id;S.embId=m.id;saveSettings();
  if(changed){engine.clearVecs();qvecCache.clear();await idx.reload()}
  if(!ai.embedder.ready||ai.embedder.model.id!==m.id)await loadEmbedder(m,!!S.ready.embed[m.id]);
  else{renderAll();idx.kickEmbed()}
}
async function setMode(mode){S.mode=mode;saveSettings();engine.clearVecs();await idx.reload();renderAll();idx.kickEmbed()}
async function downloadChat(m){
  const st=ms('chat',m.id);st.state=S.ready.chat[m.id]?'loading':'downloading';st.pct=0;st.err='';S.chatId=m.id;saveSettings();
  ai.chat.onprogress=progressTracker((pct,l,t)=>{st.pct=pct;st.loaded=l;st.total=t;renderAIThrottled();renderAskState()});
  renderAI();renderAskState();
  try{await ai.chat.load(m);S.ready.chat[m.id]=true;saveSettings();st.state='ready'}
  catch(e){st.state='error';st.err=friendly(e)}
  renderAI();renderAskState();
}
function modelRow(kind,m,active){
  const st=ms(kind,m.id),ready=!!S.ready[kind][m.id];
  const busy=st.state==='downloading'||st.state==='loading';
  let right='';
  if(busy)right=`<span class="tag warn">${st.state==='loading'?'loading':Math.round(st.pct*100)+'%'}</span>`;
  else if(ready&&active)right='<span class="tag ok">in use</span>';
  else if(ready)right=`<button class="btn sm ghost" data-ai="use-${kind}" data-id="${m.id}">Use</button>`;
  else right=`<button class="btn sm" data-ai="dl-${kind}" data-id="${m.id}"><svg class="i" style="width:16px;height:16px"><use href="#i-down"/></svg>${m.mb>=1000?(m.mb/1000).toFixed(1)+' GB':m.mb+' MB'}</button>`;
  const rm=ready&&!busy?`<button class="ib" data-ai="rm-${kind}" data-id="${m.id}" aria-label="Remove ${esc(m.name)}" style="width:32px;height:32px"><svg class="i" style="width:16px;height:16px"><use href="#i-trash"/></svg></button>`:'';
  return `<div class="mrow"><div class="mi"><b>${esc(m.name)} <span class="chip sm" style="padding:1px 8px">${esc(m.tag)}</span></b><small>${esc(m.note)}</small>${busy?`<div class="bar"><i style="width:${Math.round(st.pct*100)}%"></i></div>${st.total?`<small>${fmtSize(st.loaded||0)} of ${fmtSize(st.total)}</small>`:''}`:''}${st.state==='error'?`<small style="color:#ff9db9">${esc(st.err)}</small>`:''}</div>${right}${rm}</div>`;
}
function renderAI(){
  const gpu=hasWebGPU();
  let h=`<div class="card"><div class="dh"><div class="ic"><svg class="i"><use href="#i-spark"/></svg></div><div><b>Search brain</b><small>Finds pages by meaning, like Google Photos search. Runs fully on your phone.</small></div></div>${EMBED_MODELS.map(m=>modelRow('embed',m,m.id===S.embId)).join('')}
  <div class="switch"><div>Detail level<small>${S.mode==='deep'?'Thorough: every part of every page. Slower to build.':'Fast: one summary vector per page. Builds quickest.'}</small></div><div class="seg"><button data-ai="mode" data-id="fast" class="${S.mode==='fast'?'on':''}">Fast</button><button data-ai="mode" data-id="deep" class="${S.mode==='deep'?'on':''}">Thorough</button></div></div>
  <div class="switch"><div>Use the GPU for indexing<small>${gpu?'Experimental. Can be faster, but some phones are less stable.':'This browser has no WebGPU.'}</small></div><button class="tg" data-ai="gpu" aria-pressed="${S.gpuEmbed}" ${gpu?'':'disabled'} aria-label="Use the GPU for indexing"></button></div></div>`;
  h+=`<div class="card"><div class="dh"><div class="ic"><svg class="i"><use href="#i-chip"/></svg></div><div><b>Chat brain</b><small>Optional. A small language model that writes answers from your pages, on your phone. ${gpu?'Your browser supports the GPU.':'No GPU support here, so it will be slow.'}</small></div></div>${CHAT_MODELS.map(m=>modelRow('chat',m,m.id===S.chatId&&ai.chat.ready&&ai.chat.model.id===m.id)).join('')}<p class="sub" style="margin:10px 0 0">On a 6 GB phone start with the 0.5B or smaller model. Larger models can fail to load.</p></div>`;
  const pct=storage.quota?Math.round(100*storage.usage/storage.quota):0;
  h+=`<div class="card"><div class="dh"><div class="ic"><svg class="i"><use href="#i-lib"/></svg></div><div><b>Storage and library</b><small>Everything stays on this device.</small></div></div>
  <div class="kv"><span>Used by Inkdex</span><span>${fmtSize(storage.usage)}${storage.quota?' of '+fmtSize(storage.quota)+' ('+pct+'%)':''}</span></div>
  <div class="kv"><span>Protected from automatic cleanup</span><span>${storage.persisted?'Yes':'Not yet'}</span></div>
  <div class="switch"><div>Keep a copy of each PDF<small>Needed to open the real page with highlights. Turn off to save space. Applies to PDFs you add next.</small></div><button class="tg" data-ai="keep" aria-pressed="${S.keepCopies}" aria-label="Keep a copy of each PDF"></button></div>
  <div class="row" style="margin-bottom:0">${deferredInstall?'<button class="btn sm" data-ai="install">Install app</button>':''}${storage.persisted?'':'<button class="btn sm ghost" data-ai="persist">Protect my data</button>'}<button class="btn sm danger" data-ai="wipe"><span>Delete my whole library</span></button></div></div>`;
  $('#aipanel').innerHTML=h;
}
const renderAIThrottled=throttle(renderAI,200);
async function refreshStorage(){storage=await storageInfo();renderAI()}
$('#aipanel').addEventListener('click',async e=>{
  const b=e.target.closest('[data-ai]');if(!b||b.disabled)return;const a=b.dataset.ai,id=b.dataset.id;
  if(a==='dl-embed'){const m=EMBED_MODELS.find(x=>x.id===id);S.embId=m.id;saveSettings();engine.clearVecs();qvecCache.clear();await idx.reload();loadEmbedder(m,false)}
  if(a==='use-embed')activateEmbed(EMBED_MODELS.find(x=>x.id===id));
  if(a==='rm-embed'){const m=EMBED_MODELS.find(x=>x.id===id);await removeCached(m.hf);S.ready.embed[id]=false;MS.embed[id]={state:'idle',pct:0};if(ai.embedder.model&&ai.embedder.model.id===id)await ai.embedder.unload();saveSettings();renderAll();toast(m.name+' removed.')}
  if(a==='dl-chat')downloadChat(CHAT_MODELS.find(x=>x.id===id));
  if(a==='use-chat'){S.chatId=id;saveSettings();ai.chat.model=null;downloadChat(CHAT_MODELS.find(x=>x.id===id))}
  if(a==='rm-chat'){const m=CHAT_MODELS.find(x=>x.id===id);await removeCached(m.hf);S.ready.chat[id]=false;MS.chat[id]={state:'idle',pct:0};if(ai.chat.model&&ai.chat.model.id===id)await ai.chat.unload();saveSettings();renderAI();renderAskState();toast(m.name+' removed.')}
  if(a==='mode')setMode(id);
  if(a==='gpu'){S.gpuEmbed=!S.gpuEmbed;saveSettings();renderAI();if(S.ready.embed[S.embId])loadEmbedder(embModel(),true)}
  if(a==='keep'){S.keepCopies=!S.keepCopies;saveSettings();renderAI()}
  if(a==='persist'){await ask2persist();toast(storage.persisted?'Your library is now protected.':'Your browser did not allow it. Installing the app usually helps.')}
  if(a==='install'&&deferredInstall){deferredInstall.prompt();deferredInstall=null;renderAI()}
  if(a==='wipe'){
    if(b.dataset.sure!=='1'){b.dataset.sure='1';b.querySelector('span').textContent='Tap again to delete everything';setTimeout(()=>{b.dataset.sure='';const s=b.querySelector('span');if(s)s.textContent='Delete my whole library'},3500);return}
    await idx.removeAll();textCache.clear();pdfCache.clear();renderAll();refreshStorage();toast('Library deleted.');
  }
});
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredInstall=e;renderAI()});

/* ---------------- Ask tab ---------------- */
const chatLog=[];let asking=false;const $chat=$('#chat');
const chatReady=()=>ai.chat.ready&&ai.chat.model.id===chatModel().id;
function renderAskState(){
  const m=chatModel(),st=ms('chat',m.id),el=$('#askstate');
  if(chatReady())el.innerHTML='';
  else if(st.state==='downloading'||st.state==='loading')el.innerHTML=`<div class="hint askstate">${st.state==='loading'?'Waking the chat brain…':'Downloading the chat brain…'} ${Math.round(st.pct*100)}%<div class="bar"><i style="width:${Math.round(st.pct*100)}%"></i></div></div>`;
  else if(S.ready.chat[m.id])el.innerHTML='<div class="hint askstate">The chat brain wakes up when you send your first question.</div>';
  else el.innerHTML=`<div class="hint askstate">No chat brain installed. Ask still finds the best matching passages. For written answers, download a small model once.<br><button class="btn sm" data-go="ai">Choose a chat brain</button></div>`;
}
function chatEmpty(){
  if(chatLog.length)return;
  $chat.innerHTML=`<div class="msg a intro"><p><b>Ask anything about your PDFs.</b> I find the most relevant pages first, then answer from them and cite the page.</p><p>Pick one document to unlock summaries, quizzes, flashcards and exam-style answers.</p><div class="srcs">${['What are the main topics?','Explain this from the basics'].map(s=>`<button class="chip" data-s="${s}">${s}</button>`).join('')}</div></div>`;
}
function updateAskChips(){const one=$('#askscope').value!=='all';$$('[data-act]').forEach(b=>b.disabled=!one||asking)}
$('#askscope').onchange=updateAskChips;
function md(src,sources){
  const lines=esc(src).replace(/\r/g,'').split('\n'),out=[];let list=null;const close=()=>{if(list){out.push('</'+list+'>');list=null}};
  const inl=x=>x.replace(/`([^`]+)`/g,'<code>$1</code>').replace(/\*\*([^*]+)\*\*/g,'<strong>$1</strong>').replace(/\[(\d{1,2})\]/g,(m,n)=>sources&&sources[n-1]?`<button class="cite" data-n="${n}">${n}</button>`:m);
  for(const ln of lines){let m;
    if((m=ln.match(/^#{1,4}\s+(.*)/))){close();out.push(`<h4>${inl(m[1])}</h4>`)}
    else if((m=ln.match(/^\s*[-*•]\s+(.*)/))){if(list!=='ul'){close();out.push('<ul>');list='ul'}out.push(`<li>${inl(m[1])}</li>`)}
    else if((m=ln.match(/^\s*(\d+)[.)]\s+(.*)/))){if(list!=='ol'){close();out.push(`<ol start="${m[1]}">`);list='ol'}out.push(`<li>${inl(m[2])}</li>`)}
    else if(!ln.trim())close();else{close();out.push(`<p>${inl(ln)}</p>`)}}
  close();return out.join('');
}
const srcHtml=s=>s&&s.length?`<div class="srcs">${s.map((x,i)=>`<button class="chip" data-n="${i+1}"><b>${i+1}</b> ${esc(x.doc.name.replace(/\.pdf$/i,'').slice(0,26))} · p.${x.p}</button>`).join('')}</div>`:'';
function addMsg(role,html){const i=$chat.querySelector('.intro');if(i)i.remove();const el=document.createElement('div');el.className='msg '+(role==='u'?'u':'a');el.innerHTML=html;$chat.appendChild(el);$chat.scrollTop=$chat.scrollHeight;return el}
async function retrieve(q,docId,k=5){
  let qv=null;if(semanticReady()){try{qv=await queryVec(q)}catch(e){}}
  const m=embModel(),res=await engine.search(q,{docId,qvec:qv,floor:m.floor,rel:m.rel,textOf});if(!res)return [];
  const flat=[];res.hits.forEach(g=>g.pages.forEach(pg=>flat.push({doc:g.doc,p:pg.p,s:pg.s,chunk:pg.chunk,sem:pg.sem,kw:pg.kw})));
  flat.sort((a,b)=>b.s-a.s);return flat.slice(0,k);
}
async function excerpt(s,len=1000){
  const raw=(await docTexts(s.doc.id))[s.p-1]||'',t=clean(raw);
  if(s.sem&&s.chunk>=0){const v=engine.vec;return t.slice(v.cstart[s.chunk],v.cend[s.chunk]).slice(0,len)}
  return t.slice(0,len);
}
async function ensureChat(){
  if(chatReady())return true;
  const m=chatModel();if(!S.ready.chat[m.id])return false;
  await downloadChat(m);return chatReady();
}
async function converse(label,builder,sources){
  if(asking)return;asking=true;updateAskChips();
  addMsg('u',esc(label));chatLog.push({role:'user',text:label});
  const el=addMsg('a','<span class="dots"><i></i><i></i><i></i></span>');el._src=sources;
  const finish=text=>{chatLog.push({role:'assistant',text:text||'(no answer)'});asking=false;setSend(false);updateAskChips();$chat.scrollTop=$chat.scrollHeight};
  if(!(await ensureChat())){
    let h='<p>No chat brain is loaded, so here are the best matching passages from your documents.</p>';
    if(sources.length){h+=(await Promise.all(sources.map(async(s,i)=>`<div class="passage"><b>[${i+1}] ${esc(s.doc.name.replace(/\.pdf$/i,''))} · p.${s.p}</b><br>${esc((await excerpt(s,420))+'…')}</div>`))).join('')+srcHtml(sources)}
    else h+='<p>Nothing matched. Try different words.</p>';
    el.innerHTML=h;return finish('(passages only)');
  }
  const history=chatLog.slice(0,-1).slice(-4).map(m=>({role:m.role,content:m.text}));while(history.length&&history[0].role!=='user')history.shift();
  setSend(true);let final='';
  try{
    const msgs=await builder(history);
    await ai.chat.generate(msgs,t=>{final+=t;el.innerHTML=md(final,sources)+srcHtml(sources);$chat.scrollTop=$chat.scrollHeight},450);
    el.innerHTML=md(final||'(no answer)',sources)+srcHtml(sources);
  }catch(e){el.innerHTML=(final?md(final,sources):'')+`<p style="color:#ff9db9">${esc(friendly(e))}</p>`}
  finish(final);
}
async function ask(q){
  q=q.trim();if(!q||asking)return;$('#askin').value='';autosize();
  const sc=$('#askscope').value,src=await retrieve(q,sc);
  await converse(q,async history=>{
    const ctx=(await Promise.all(src.map(async(s,i)=>`[${i+1}] ${s.doc.name.replace(/\.pdf$/i,'')}, page ${s.p}\n${await excerpt(s)}`))).join('\n\n');
    const sys='You are a careful study assistant inside a PDF search app. Answer using ONLY the numbered excerpts. Cite the excerpt like [1]. Explain simply, starting from the basics. If the excerpts do not contain the answer, say you could not find it in the documents.';
    return [{role:'system',content:sys},...history,{role:'user',content:`Excerpts:\n${ctx||'(none found)'}\n\nQuestion: ${q}`}];
  },src);
}
const ACTS={
  summary:['Summarize','Summarize this document in simple language. Give a one-sentence gist, then the key points as bullets with the most important first, then a few key terms with one-line definitions.'],
  topics:['Key topics','List the main topics and sub-topics of this document as an outline, from fundamentals to advanced, with one line on each.'],
  quiz:['Quiz me','Write 5 multiple-choice questions that test understanding of this document, easy to hard. Number them, give options A to D, and put an Answers section at the end.'],
  cards:['Flashcards','Make 10 flashcards on the most important facts and terms. Format each as a numbered item with "Q:" then "A:" on the next line. Keep answers short.'],
  exam:['Exam answer','Write an exam-style answer on the main topic of this document with a heading for each of: Definition, Types, Diagram (describe what to draw), Technical terms, Example, Applications, Advantages. Be concise.']
};
async function docSample(doc,max=4200){
  const texts=await docTexts(doc.id),outline=doc.heads.slice(0,40).map(h=>`- ${h.t} (p.${h.p})`).join('\n').slice(0,1200);
  const pages=texts.map((t,i)=>({p:i+1,t:clean(t)})).filter(x=>x.t.length>40),want=Math.min(pages.length,10),per=Math.floor((max-0)/Math.max(1,want));
  const pick=[];for(let k=0;k<want;k++)pick.push(pages[Math.floor(k*pages.length/want)]);
  return (outline?`Outline:\n${outline}\n\n`:'')+pick.map(x=>`Page ${x.p}: ${x.t.slice(0,per)}`).join('\n\n');
}
$$('[data-act]').forEach(b=>b.onclick=async()=>{
  const doc=engine.byId.get($('#askscope').value);if(!doc||asking)return;const [label,instr]=ACTS[b.dataset.act];
  await converse(`${label}: ${doc.name.replace(/\.pdf$/i,'')}`,async()=>[{role:'system',content:'You are a careful study assistant. Use only the document material given.'},{role:'user',content:`${instr}\n\nDOCUMENT: ${doc.name}\n\n${await docSample(doc)}`}],[]);
});
$chat.addEventListener('click',e=>{
  const s=e.target.closest('[data-s]');if(s){ask(s.dataset.s);return}
  const n=e.target.closest('[data-n]');if(!n)return;const host=n.closest('.msg'),x=host&&host._src&&host._src[+n.dataset.n-1];
  if(x)openViewer(x.doc.id,x.p,[]);
});
function setSend(on){const b=$('#asksend');b.innerHTML=`<svg class="i"><use href="#i-${on?'stop':'send'}"/></svg>`;b.setAttribute('aria-label',on?'Stop':'Send')}
function autosize(){const t=$('#askin');t.style.height='auto';t.style.height=Math.min(120,t.scrollHeight)+'px'}
$('#askin').addEventListener('input',autosize);
$('#askin').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey&&!/Mobi|Android/i.test(navigator.userAgent)){e.preventDefault();ask($('#askin').value)}});
$('#asksend').onclick=()=>{if(asking){ai.chat.stop();return}ask($('#askin').value)};

// developer hooks used by the automated tests
window.__inkdex={engine,idx,S:()=>S,ai,store,showTab,runSearch};
boot();
