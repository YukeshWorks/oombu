package com.yukeshworks.inkdex;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;
import android.util.Base64;
import android.view.WindowManager;
import android.webkit.MimeTypeMap;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/** Finds every supported document on the phone, reads them, and shares / opens them with other apps. */
@CapacitorPlugin(name = "PdfScan")
public class PdfScanPlugin extends Plugin {

    /** Document types found by the one-tap phone scan (a subset of SUPPORTED_EXTS in www/js/office.js). */
    private static final Set<String> EXTS = new HashSet<>(Arrays.asList(
        "pdf", "docx", "docm", "dotx", "odt", "rtf", "pptx", "pptm", "ppsx", "odp",
        "xlsx", "xlsm", "ods", "csv", "tsv", "txt", "md", "markdown"));
    // json, log, html and xml are left out of the phone scan on purpose (apps leave thousands of them); they can still be picked by hand.

    private static String extOf(String name) {
        int i = name.lastIndexOf('.');
        return i < 0 ? "" : name.substring(i + 1).toLowerCase();
    }

    private static String mimeOf(String name) {
        String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extOf(name));
        return m != null ? m : "application/octet-stream";
    }

    private boolean granted() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) return Environment.isExternalStorageManager();
        return ContextCompat.checkSelfPermission(getContext(), Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    @PluginMethod
    public void hasAccess(PluginCall call) {
        JSObject r = new JSObject();
        r.put("granted", granted());
        call.resolve(r);
    }

    /** Android 11+: opens the "All files access" screen for Inkdex. Older: normal storage permission prompt. */
    @PluginMethod
    public void requestAccess(PluginCall call) {
        if (granted()) { call.resolve(); return; }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Intent i = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                i.setData(Uri.parse("package:" + getContext().getPackageName()));
                try { getActivity().startActivity(i); }
                catch (ActivityNotFoundException e) { getActivity().startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)); }
            } else {
                ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 4711);
            }
            call.resolve();
        } catch (Exception e) {
            call.reject("Could not open the permission screen", e);
        }
    }

    /** Walks shared storage (and SD cards) for supported documents. Skips hidden folders and Android/data, Android/obb. */
    @PluginMethod
    public void scan(PluginCall call) {
        if (!granted()) { call.reject("Storage access not granted", "NO_ACCESS"); return; }
        execute(() -> {
            try {
                JSArray out = new JSArray();
                Set<String> seen = new HashSet<>();
                ArrayDeque<File> stack = new ArrayDeque<>();
                stack.push(Environment.getExternalStorageDirectory());
                File[] ext = getContext().getExternalFilesDirs(null);
                if (ext != null) for (File f : ext) {
                    if (f == null) continue;
                    String p = f.getAbsolutePath();
                    int k = p.indexOf("/Android/");
                    if (k > 0) stack.push(new File(p.substring(0, k)));
                }
                int dirs = 0;
                while (!stack.isEmpty() && dirs < 60000) {
                    File dir = stack.pop();
                    String canon;
                    try { canon = dir.getCanonicalPath(); } catch (Exception e) { continue; }
                    if (!seen.add(canon)) continue;
                    dirs++;
                    File[] list = dir.listFiles();
                    if (list == null) continue;
                    for (File f : list) {
                        String name = f.getName();
                        if (name.startsWith(".")) continue;
                        if (f.isDirectory()) {
                            if (name.equals("data") || name.equals("obb")) {
                                File parent = f.getParentFile();
                                if (parent != null && parent.getName().equals("Android")) continue;
                            }
                            stack.push(f);
                        } else if (EXTS.contains(extOf(name)) && f.length() > 0 && !name.startsWith("~$")) {
                            JSObject o = new JSObject();
                            o.put("path", f.getAbsolutePath());
                            o.put("name", name);
                            o.put("size", f.length());
                            o.put("modified", f.lastModified());
                            out.put(o);
                        }
                    }
                }
                JSObject r = new JSObject();
                r.put("files", out);
                call.resolve(r);
            } catch (Exception e) {
                call.reject("Scan failed: " + e.getMessage(), e);
            }
        });
    }

    /** Fallback reader (base64). The app normally reads files through the WebView file server instead. */
    @PluginMethod
    public void read(PluginCall call) {
        String path = call.getString("path");
        if (path == null) { call.reject("path missing"); return; }
        execute(() -> {
            try (InputStream in = new FileInputStream(new File(path))) {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                JSObject r = new JSObject();
                r.put("data", Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP));
                call.resolve(r);
            } catch (Exception e) {
                call.reject("Could not read file: " + e.getMessage(), e);
            }
        });
    }

    private Uri uriFor(File f) {
        return FileProvider.getUriForFile(getContext(), getContext().getPackageName() + ".fileprovider", f);
    }

    private File cacheCopy(PluginCall call) throws Exception {
        String name = call.getString("name", "document.pdf").replaceAll("[\\\\/:*?\"<>|]", "_");
        String data = call.getString("data");
        if (data == null) throw new Exception("data missing");
        File dir = new File(getContext().getCacheDir(), "share");
        if (!dir.exists()) dir.mkdirs();
        File f = new File(dir, name);
        try (FileOutputStream os = new FileOutputStream(f)) { os.write(Base64.decode(data, Base64.DEFAULT)); }
        return f;
    }

    private void doShare(PluginCall call, File f) {
        Uri uri = uriFor(f);
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType(mimeOf(f.getName()));
        send.putExtra(Intent.EXTRA_STREAM, uri);
        send.putExtra(Intent.EXTRA_SUBJECT, f.getName());
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        Intent chooser = Intent.createChooser(send, "Share " + f.getName());
        chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        getActivity().startActivity(chooser);
        call.resolve();
    }

    private void doOpen(PluginCall call, File f) {
        Intent view = new Intent(Intent.ACTION_VIEW);
        view.setDataAndType(uriFor(f), mimeOf(f.getName()));
        view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        Intent chooser = Intent.createChooser(view, "Open with");
        chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        getActivity().startActivity(chooser);
        call.resolve();
    }

    @PluginMethod
    public void share(PluginCall call) {
        try {
            File f = new File(call.getString("path", ""));
            if (!f.exists()) { call.reject("File not found", "NOT_FOUND"); return; }
            doShare(call, f);
        } catch (Exception e) { call.reject("Share failed: " + e.getMessage(), e); }
    }

    @PluginMethod
    public void shareData(PluginCall call) {
        try { doShare(call, cacheCopy(call)); } catch (Exception e) { call.reject("Share failed: " + e.getMessage(), e); }
    }

    @PluginMethod
    public void openWith(PluginCall call) {
        try {
            File f = new File(call.getString("path", ""));
            if (!f.exists()) { call.reject("File not found", "NOT_FOUND"); return; }
            doOpen(call, f);
        } catch (Exception e) { call.reject("Open failed: " + e.getMessage(), e); }
    }

    @PluginMethod
    public void openData(PluginCall call) {
        try { doOpen(call, cacheCopy(call)); } catch (Exception e) { call.reject("Open failed: " + e.getMessage(), e); }
    }

    /** Keeps the screen on while Inkdex is indexing. */
    @PluginMethod
    public void keepAwake(PluginCall call) {
        final boolean on = Boolean.TRUE.equals(call.getBoolean("on", false));
        getActivity().runOnUiThread(() -> {
            if (on) getActivity().getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            else getActivity().getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        });
        call.resolve();
    }
}
