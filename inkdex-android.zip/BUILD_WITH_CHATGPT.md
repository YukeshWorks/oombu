# For ChatGPT: build this Capacitor Android project into an APK

This is a complete, ready Capacitor 8 Android project for "Inkdex" (offline PDF search). Do NOT redesign or rewrite it.

Already included:
- `www/` web app (search, on-device AI, library with file dates, share buttons)
- `android/` native project with a custom plugin `PdfScanPlugin.java` (one-tap scan of all PDFs via All files access, read, share, open-with, keep-screen-on), registered in `MainActivity.java`
- Manifest permissions, FileProvider paths, dark icons/splash, a fixed signing key (`android/app/inkdex.keystore`, password `inkdex123`, alias `inkdex`)
- `.github/workflows/apk.yml` that builds `inkdex.apk` and publishes it to GitHub Releases

Your job:
1. If you can run Node 22 + JDK 21 + Android SDK: `npm ci && npx cap sync android && cd android && ./gradlew assembleRelease`, then give me `android/app/build/outputs/apk/release/app-release.apk` renamed to `inkdex.apk`.
2. If you cannot run Gradle: tell me exactly how to push this folder to a new GitHub repo from my Android phone or browser so the included workflow builds it, and where to download the APK.
3. If the build fails, fix only the reported error with the smallest change, and tell me what you changed.
4. Be honest about what you actually ran and what you did not.
