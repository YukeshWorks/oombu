// Background pipeline: read PDFs -> save keyword index -> (optional) embed chunks with the on-device AI.
import {keepAwake} from './native.js';
import {extractAny,kindOf,OLD_EXTS,extOf} from './office.js';
import * as store from './store.js';
import {extractPDF,analyzeDoc,topTopics,clean,sectionOf,tick} from './textproc.js';

const PAUSED=new Error('paused');
export const docRecord=d=>{const {i,base,nameStems,...m}=d;return m};

export function chunkDoc(doc,texts,mode){
  const target=mode==='deep'?520:850,out=[];
  texts.forEach((raw,pi)=>{
    const t=clean(raw||'');if(t.length<24)return;
    const sec=sectionOf(doc,pi+1);let s=0;
    while(s<t.length){
      let e=Math.min(t.length,s+target);if(e<t.length){const sp=t.lastIndexOf(' ',e);if(sp>s+target*.6)e=sp}
      const body=t.slice(s,e);out.push({p:pi+1,s,e,text:(sec&&!body.startsWith(sec)?sec+'. ':'')+body});
      s=e;if(mode!=='deep')break;while(t[s]===' ')s++;
    }
  });
  return out;
}

export class Indexer{
  constructor(engine,ai,cfg){
    this.e=engine;this.ai=ai;this.cfg=cfg;this.onchange=()=>{};
    this.read={active:false,total:0,done:0,skipped:0,failed:[],cur:''};
    this.emb={active:false,err:'',rate:0,cpp:1,startedAt:0};
    this.fps=new Set();this.pool=null;this.running=false;this.locks=0;this.wl=null;this.lastEmit=0;this.queue=[];
    document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible'&&this.locks>0)this.getLock()});
  }
  emit(force){const n=performance.now();if(force||n-this.lastEmit>250){this.lastEmit=n;this.onchange()}}
  vkey(){const c=this.cfg();return c.model.id+'|'+c.mode}
  syncFps(){this.fps=new Set(this.e.docs.map(d=>d.fp))}
  pendingDocs(){const vk=this.vkey();return this.e.docs.filter(d=>d.vkey!==vk)}
  async getLock(){try{if('wakeLock' in navigator&&!this.wl){this.wl=await navigator.wakeLock.request('screen');this.wl.addEventListener('release',()=>{this.wl=null})}}catch(e){}}
  async acquire(){this.locks++;if(this.locks===1)keepAwake(true);await this.getLock()}
  async release(){this.locks=Math.max(0,this.locks-1);if(!this.locks)keepAwake(false);if(!this.locks&&this.wl){try{await this.wl.release()}catch(e){}this.wl=null}}

  /* ---------- phase 1: read PDFs ---------- */
  async addFiles(files){
    const list=[...files].filter(f=>kindOf(f.name)||OLD_EXTS.includes(extOf(f.name))||(/pdf/i.test(f.type)&&!extOf(f.name)));
    if(!list.length)return {added:0,skipped:0,failed:0};
    this.read.total+=list.length;this.read.active=true;this.queue.push(...list);this.emit(true);
    if(this.reading)return this.reading;
    this.reading=(async()=>{
      await this.acquire();
      try{
        if(!this.pool){const n=Math.max(1,Math.min(3,Math.floor((navigator.hardwareConcurrency||4)/3)));this.pool=Array.from({length:n},(_,k)=>new pdfjsLib.PDFWorker({name:'inkdex-'+k}))}
        await Promise.all(this.pool.map(async w=>{for(;;){const f=this.queue.shift();if(!f)return;await this.ingest(f,w)}}));
      }finally{
        this.read.active=false;this.reading=null;
        try{await this.e.saveSnapshot()}catch(e){}
        await this.release();this.emit(true);
        this.kickEmbed();
      }
    })();
    return this.reading;
  }
  async ingest(file,worker){
    const fp=`${file.name}|${file.size}|${file.lastModified||0}`;
    this.read.cur=file.name;
    if(this.fps.has(fp)){this.read.skipped++;this.read.done++;this.emit();return}
    this.fps.add(fp);
    try{
      const r=await extractAny(file,worker);
      if(!r.n)throw new Error('no pages');
      const id='d'+Date.now().toString(36)+Math.random().toString(36).slice(2,8);
      const idx=analyzeDoc(r.texts,r.heads);idx.id=id;
      const path=file.nativePath||null,keep=!path&&!!this.cfg().keepCopies;
      const meta={id,name:file.name,kind:kindOf(file.name)||'pdf',size:file.size,fp,path,mtime:file.lastModified||0,n:r.n,heads:r.heads,scanned:r.scanned,added:Date.now(),vkey:null,hasFile:keep||!!path,topics:topTopics(idx,r.heads,r.n)};
      await store.putDocBundle(meta,r.texts,idx,keep?file:null);
      this.e.addDoc(meta,idx);
      if(this.e.deltaDocs>=120)this.e.compact();
    }catch(err){
      this.fps.delete(fp);
      const m=String(err&&err.message||err);
      this.read.failed.push({name:file.name,why:/password/i.test(m)?'password protected':/storage|quota/i.test(m)?'storage is full':/Invalid PDF|no pages/i.test(m)?'not a readable file':m.slice(0,90)});
    }
    this.read.done++;this.emit();
    if(this.read.done%25===0)await tick();
  }
  resetReadStats(){if(!this.read.active)this.read={active:false,total:0,done:0,skipped:0,failed:[],cur:''}}

  /* ---------- phase 2: AI meaning index ---------- */
  eta(){
    if(!this.emb.rate)return 0;
    const pages=this.pendingDocs().reduce((a,d)=>a+d.n,0);
    return Math.round(pages*this.emb.cpp/this.emb.rate);
  }
  embedProgress(){const n=this.e.docs.length;if(!n)return 0;return 1-this.pendingDocs().length/n}
  kickEmbed(){
    if(this.running)return;const c=this.cfg();
    if(c.paused||!this.ai.embedder.ready||this.ai.embedder.model.id!==c.model.id)return;
    if(!this.pendingDocs().length)return;
    this.running=true;this.emb.active=true;this.emb.err='';this.emit(true);
    (async()=>{
      await this.acquire();
      try{
        for(;;){
          const cc=this.cfg();if(cc.paused||!this.ai.embedder.ready||this.ai.embedder.model.id!==cc.model.id)break;
          const vk=this.vkey(),todo=this.pendingDocs();if(!todo.length)break;
          await this.embedDoc(todo[0],vk);this.emit();
        }
      }catch(err){if(err!==PAUSED)this.emb.err=String(err&&err.message||err)}
      finally{this.running=false;this.emb.active=false;await this.release();this.emit(true)}
    })();
  }
  async embedDoc(doc,vk){
    const c=this.cfg(),emb=this.ai.embedder;
    const texts=await store.get('texts',doc.id);
    const chunks=chunkDoc(doc,texts||[],c.mode);
    if(!chunks.length){doc.vkey=vk;await store.put('docs',doc.id,docRecord(doc));return}
    let data=null,dim=0;const BATCH=8;
    for(let i=0;i<chunks.length;i+=BATCH){
      if(this.cfg().paused)throw PAUSED;
      const batch=chunks.slice(i,i+BATCH),t0=performance.now();
      const r=await emb.embed(batch.map(x=>x.text),'passage');
      if(!data){dim=r.dim;data=new Int8Array(chunks.length*dim)}
      const f=r.data;
      for(let b=0;b<batch.length;b++)for(let j=0;j<dim;j++){const q=Math.round(f[b*dim+j]*127);data[(i+b)*dim+j]=q>127?127:q<-127?-127:q}
      const rate=batch.length/Math.max(.001,(performance.now()-t0)/1000);
      this.emb.rate=this.emb.rate?this.emb.rate*.8+rate*.2:rate;
      this.emit();await tick();
    }
    this.emb.cpp=this.emb.cpp*.7+(chunks.length/Math.max(1,doc.n))*.3;
    const rec={id:doc.id,key:vk,dim,n:chunks.length,data,cpage:Uint32Array.from(chunks.map(x=>x.p)),cstart:Uint32Array.from(chunks.map(x=>x.s)),cend:Uint32Array.from(chunks.map(x=>x.e))};
    await store.put('vecs',doc.id,rec);
    doc.vkey=vk;await store.put('docs',doc.id,docRecord(doc));
    this.e.addVecs(doc,rec);
  }

  /* ---------- housekeeping ---------- */
  async reload(onProg){
    const r=await this.e.loadAll(this.vkey(),onProg);this.syncFps();
    if(r.rebuilt>0){try{await this.e.saveSnapshot()}catch(e){}}   // first start after an interrupted run: save a fresh snapshot
    this.emit(true);return r;
  }
  async removeDoc(id){const m=this.e.byId.get(id);await store.delDoc(id);this.e.removeDoc(id);if(m)this.fps.delete(m.fp);this.emit(true)}
  async removeAll(){await store.clearAll();try{await store.del('meta','snapshot')}catch(e){}this.e.reset();this.fps=new Set();this.emit(true)}
}
