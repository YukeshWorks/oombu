// IndexedDB wrapper. One database, several stores, all keyed by document id.
const STORES=['docs','texts','idx','vecs','files','meta'];
let db=null;
export async function open(){
  db=await new Promise((res,rej)=>{
    const r=indexedDB.open('inkdex2',1);
    r.onupgradeneeded=()=>{for(const s of STORES)if(!r.result.objectStoreNames.contains(s))r.result.createObjectStore(s)};
    r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error);
  });
  db.onversionchange=()=>db.close();
}
const req=(store,mode,fn)=>new Promise((res,rej)=>{
  const t=db.transaction(store,mode);const out=fn(t.objectStore(store));
  t.oncomplete=()=>res(out&&'result' in out?out.result:undefined);t.onerror=()=>rej(t.error);t.onabort=()=>rej(t.error||new Error('Storage write was aborted'));
});
export const put=(store,key,val)=>req(store,'readwrite',s=>s.put(val,key));
export const get=(store,key)=>req(store,'readonly',s=>s.get(key));
export const del=(store,key)=>req(store,'readwrite',s=>s.delete(key));
export const allValues=store=>req(store,'readonly',s=>s.getAll());
export const page=(store,after,count)=>req(store,'readonly',s=>s.getAll(after===undefined?undefined:IDBKeyRange.lowerBound(after,true),count));
export const count=store=>req(store,'readonly',s=>s.count());
export const clearAll=()=>new Promise((res,rej)=>{const names=['docs','texts','idx','vecs','files'];const t=db.transaction(names,'readwrite');names.forEach(s=>t.objectStore(s).clear());t.oncomplete=res;t.onerror=()=>rej(t.error)});
export async function delDoc(id){
  await new Promise((res,rej)=>{const t=db.transaction(['docs','texts','idx','vecs','files'],'readwrite');['docs','texts','idx','vecs','files'].forEach(s=>t.objectStore(s).delete(id));t.oncomplete=res;t.onerror=()=>rej(t.error)});
}
/** Save everything for a freshly read document in one transaction so a crash never leaves half a document. */
export async function putDocBundle(meta,texts,idx,file){
  await new Promise((res,rej)=>{
    const names=file?['docs','texts','idx','files']:['docs','texts','idx'];
    const t=db.transaction(names,'readwrite');
    t.objectStore('docs').put(meta,meta.id);t.objectStore('texts').put(texts,meta.id);t.objectStore('idx').put(idx,meta.id);
    if(file)t.objectStore('files').put(file,meta.id);
    t.oncomplete=res;t.onerror=()=>rej(t.error);t.onabort=()=>rej(t.error||new Error('Storage write was aborted (storage may be full)'));
  });
}
