// Runs the search-brain (embedding) model off the main thread so the screen stays smooth.
import {pipeline,env} from '../vendor/transformers.min.js';
env.allowLocalModels=false;env.allowRemoteModels=true;env.useBrowserCache=true;
env.backends.onnx.wasm.wasmPaths=new URL('../vendor/',import.meta.url).href;
env.backends.onnx.wasm.proxy=false;
let ext=null;
const send=(m,t)=>postMessage(m,t||[]);
onmessage=async e=>{
  const m=e.data;
  try{
    if(m.type==='load'){
      if(m.local){env.allowLocalModels=true;env.localModelPath=m.local;env.allowRemoteModels=false}
      if(ext){try{await ext.dispose()}catch(_){}ext=null}
      let device=m.device||'wasm';
      const mk=d=>pipeline('feature-extraction',m.hf,{dtype:m.dtype,device:d,progress_callback:p=>send({type:'progress',p})});
      try{ext=await mk(device)}catch(err){if(device!=='wasm'){device='wasm';ext=await mk('wasm')}else throw err}
      send({id:m.id,ok:true,device});
    }else if(m.type==='embed'){
      if(!ext)throw new Error('The search brain is not loaded');
      const out=await ext(m.texts,{pooling:'mean',normalize:true});
      const data=out.data instanceof Float32Array?out.data:Float32Array.from(out.data);
      send({id:m.id,ok:true,dim:out.dims[out.dims.length-1],data},[data.buffer]);
    }else if(m.type==='dispose'){
      if(ext){try{await ext.dispose()}catch(_){}ext=null}send({id:m.id,ok:true});
    }
  }catch(err){send({id:m.id,ok:false,error:String(err&&err.message||err)})}
};
