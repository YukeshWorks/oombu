// The search engine. Postings live in compact typed arrays ("main") plus a small growing "delta" for newly added documents.
// A saved snapshot of "main" lets the app start without re-reading every document.
import {indexTokens,words,stem,STOP,rootOf,lev,tick} from './textproc.js';
import * as store from './store.js';
const K1=1.4,B=.75,SNAP_VER=2,EMPTY=[];
const emptyMain=()=>({terms:[],vocab:new Map(),off:new Uint32Array(1),post:new Int32Array(0)});

export function parseQuery(q){
  const phrases=[];q=q.replace(/"([^"]+)"/g,(_,p)=>{phrases.push(p.toLowerCase().trim());return ' '+p+' '});
  const raw=words(q);let terms=raw.filter(t=>!STOP.has(t));if(!terms.length)terms=raw;
  return {stems:[...new Set(terms.map(stem))],phrases,flat:raw.join(' ')};
}

export class Engine{
  constructor(){this.reset()}
  reset(){
    this.all=[];this.byId=new Map();this._live=null;this.livePages=0;
    this.main=emptyMain();this.delta=new Map();this.deltaDocs=0;
    this.pDoc=[];this.pNo=[];this.pLen=[];this.totalLen=0;
    this.clearVecs();
  }
  clearVecs(){this.vec={dim:0,n:0,data:null,cdoc:[],cpage:[],cstart:[],cend:[]}}
  get docs(){return this._live||(this._live=this.all.filter(d=>!d.dead))}
  get nPages(){return this.livePages}
  get nTerms(){return this.main.terms.length+this.delta.size}

  /* ---- adding / removing documents ---- */
  addDoc(meta,idx){
    meta.i=this.all.length;this.all.push(meta);this.byId.set(meta.id,meta);this._live=null;meta.base=this.pDoc.length;this.livePages+=meta.n;
    for(let p=0;p<meta.n;p++){this.pDoc.push(meta.i);this.pNo.push(p+1);const l=idx.lens[p]||0;this.pLen.push(l);this.totalLen+=l}
    const a=idx.post,terms=idx.terms,off=meta.base<<11,d=this.delta;
    for(let k=0;k<a.length;k+=2){const w=terms[a[k]];let arr=d.get(w);if(!arr)d.set(w,arr=[]);arr.push((a[k+1]+off)|0)}
    meta.nameStems=new Set(indexTokens(meta.name.replace(/\.[a-z0-9]{1,8}$/i,'')));this.deltaDocs++;
  }
  removeDoc(id){
    const m=this.byId.get(id);if(!m)return;m.dead=true;this.byId.delete(id);this._live=null;this.livePages-=m.n;
  }
  /** Fold the delta into the compact main arrays. Cheap typed-array copies. */
  compact(){
    if(!this.delta.size)return false;
    const M=this.main,terms=M.terms.slice(),vocab=new Map(M.vocab),n0=terms.length;
    for(const w of this.delta.keys())if(!vocab.has(w)){vocab.set(w,terms.length);terms.push(w)}
    const T=terms.length,len=new Uint32Array(T);
    for(let g=0;g<n0;g++)len[g]=M.off[g+1]-M.off[g];
    for(const [w,arr] of this.delta)len[vocab.get(w)]+=arr.length;
    const off=new Uint32Array(T+1);for(let g=0;g<T;g++)off[g+1]=off[g]+len[g];
    const post=new Int32Array(off[T]),cur=new Uint32Array(T);
    for(let g=0;g<n0;g++){const s=M.off[g],e=M.off[g+1];if(e>s)post.set(M.post.subarray(s,e),off[g]);cur[g]=off[g]+(e-s)}
    for(let g=n0;g<T;g++)cur[g]=off[g];
    for(const [w,arr] of this.delta){const g=vocab.get(w);post.set(arr,cur[g]);cur[g]+=arr.length}
    this.main={terms,vocab,off,post};this.delta=new Map();this.deltaDocs=0;return true;
  }
  addVecs(meta,rec){
    const v=this.vec,dim=rec.dim;if(v.dim&&v.dim!==dim)return false;v.dim=dim;
    const need=(v.n+rec.n)*dim;
    if(!v.data||v.data.length<need){const nd=new Int8Array(Math.max(need,Math.floor((v.data?v.data.length:0)*1.5),dim*4096));if(v.data)nd.set(v.data.subarray(0,v.n*dim));v.data=nd}
    v.data.set(rec.data,v.n*dim);
    for(let c=0;c<rec.n;c++){v.cdoc.push(meta.i);v.cpage.push(rec.cpage[c]);v.cstart.push(rec.cstart[c]);v.cend.push(rec.cend[c])}
    v.n+=rec.n;return true;
  }

  /* ---- snapshot ---- */
  makeSnapshot(){
    this.compact();const M=this.main;
    return {ver:SNAP_VER,terms:M.terms.join('\n'),off:M.off,post:M.post,pDoc:Uint32Array.from(this.pDoc),pNo:Uint32Array.from(this.pNo),pLen:Uint32Array.from(this.pLen),
      docIds:this.all.map(d=>d.id),docBase:Uint32Array.from(this.all.map(d=>d.base)),docN:Uint32Array.from(this.all.map(d=>d.n)),totalLen:this.totalLen};
  }
  async saveSnapshot(){await store.put('meta','snapshot',this.makeSnapshot())}
  /** Rebuild from storage: snapshot first (fast), then any documents added after it was taken. Returns {fromSnapshot, rebuilt}. */
  async loadAll(vkey,onProg){
    this.reset();
    const metas=await store.allValues('docs'),byMeta=new Map(metas.map(m=>[m.id,m]));
    let snap=null;try{snap=await store.get('meta','snapshot')}catch(e){}
    const inSnap=new Set();let fromSnapshot=false;
    if(snap&&snap.ver===SNAP_VER&&snap.docIds&&snap.off&&snap.post){
      fromSnapshot=true;
      const terms=snap.terms?snap.terms.split('\n'):[],vocab=new Map();for(let i=0;i<terms.length;i++)vocab.set(terms[i],i);
      this.main={terms,vocab,off:snap.off,post:snap.post};
      this.pDoc=Array.from(snap.pDoc);this.pNo=Array.from(snap.pNo);this.pLen=Array.from(snap.pLen);this.totalLen=snap.totalLen;
      snap.docIds.forEach((id,i)=>{
        const m=byMeta.get(id);
        if(m){m.i=i;m.base=snap.docBase[i];m.nameStems=new Set(indexTokens(m.name.replace(/\.[a-z0-9]{1,8}$/i,'')));this.all[i]=m;this.byId.set(id,m);inSnap.add(id);this.livePages+=m.n}
        else this.all[i]={id,dead:true,n:snap.docN[i],base:snap.docBase[i],i,name:'',nameStems:new Set(),heads:[]};
      });
      onProg&&onProg(.5);
    }
    let after,done=0,rebuilt=0;const todo=metas.length-inSnap.size;
    for(;;){
      const rows=await store.page('idx',after,150);if(!rows.length)break;
      for(const r of rows){const m=byMeta.get(r.id);if(m&&!inSnap.has(r.id)){this.addDoc(m,r);rebuilt++;if(this.deltaDocs>=150)this.compact()}}
      after=rows[rows.length-1].id;done+=rows.length;onProg&&onProg(.5+.4*Math.min(1,done/Math.max(1,todo+inSnap.size)));await tick();
    }
    this.compact();this._live=null;
    if(vkey){
      after=undefined;
      for(;;){
        const rows=await store.page('vecs',after,100);if(!rows.length)break;
        for(const r of rows){const m=this.byId.get(r.id);if(m&&r.key===vkey&&m.vkey===vkey)this.addVecs(m,r)}
        after=rows[rows.length-1].id;await tick();
      }
    }
    onProg&&onProg(1);
    return {fromSnapshot,rebuilt};
  }

  /* ---- keyword search ---- */
  termExists(t){return this.main.vocab.has(t)||this.delta.has(t)}
  expandTerm(t,isLast,w){
    const out=new Map(),M=this.main.terms,D=this.delta;
    if(this.termExists(t))out.set(t,w);
    if((isLast||!out.size)&&t.length>=2){
      let c=0;
      for(const v of M){if(v!==t&&v.startsWith(t)){out.set(v,w*.7);if(++c>=40)break}}
      if(c<40)for(const v of D.keys()){if(v!==t&&v.startsWith(t)){out.set(v,w*.7);if(++c>=40)break}}
    }
    if(!out.size&&t.length>=4){
      const md=t.length>=8?2:1,c0=t.charCodeAt(0),chk=v=>{if(v.charCodeAt(0)!==c0||Math.abs(v.length-t.length)>md)return;if(lev(v,t,md)<=md)out.set(v,w*.55)};
      for(const v of M)chk(v);for(const v of D.keys())chk(v);
    }
    return out;
  }
  keyword(q,{docIdx=-1,headOnly=false,extra=[]}={}){
    const pq=parseQuery(q);if(!pq.stems.length&&!extra.length)return null;
    const groups=[],roots=new Set();
    pq.stems.forEach((t,i)=>{const m=this.expandTerm(t,i===pq.stems.length-1,1);groups.push({m,opt:false});if(m.size)m.forEach((_,v)=>roots.add(rootOf(v)));else roots.add(rootOf(t))});
    extra.forEach(raw=>{indexTokens(raw).forEach(t=>{if(pq.stems.includes(t))return;const m=this.expandTerm(t,false,.45);if(m.size){groups.push({m,opt:true});m.forEach((_,v)=>roots.add(rootOf(v)))}})});
    const N=this.pDoc.length||1,AVG=Math.max(1,this.totalLen/N),reqN=groups.filter(g=>!g.opt).length,acc=new Map(),M=this.main,pDoc=this.pDoc,pLen=this.pLen,all=this.all;
    for(const g of groups){
      const best=new Map();
      for(const [vt,w] of g.m){
        const gi=M.vocab.get(vt),dArr=this.delta.get(vt)||EMPTY,s0=gi===undefined?0:M.off[gi],e0=gi===undefined?0:M.off[gi+1];
        const df=(e0-s0)+dArr.length,idf=Math.log(1+(N-df+.5)/(df+.5));
        const visit=v=>{
          const pid=v>>>11,di=pDoc[pid];if((docIdx>=0&&di!==docIdx)||all[di].dead)return;
          const tb=(v>>>3)&255,th=v&7,tf=headOnly?th*4:tb+4*th;if(!tf)return;
          const sc=w*idf*tf*(K1+1)/(tf+K1*(1-B+B*pLen[pid]/AVG));if(sc>(best.get(pid)||0))best.set(pid,sc);
        };
        for(let k=s0;k<e0;k++)visit(M.post[k]);for(let k=0;k<dArr.length;k++)visit(dArr[k]);
      }
      best.forEach((sc,pid)=>{let a=acc.get(pid);if(!a)acc.set(pid,a={s:0,m:0});a.s+=sc;if(!g.opt)a.m++});
    }
    const list=[];
    acc.forEach((a,pid)=>{
      let s=a.s;if(reqN){s*=a.m===0?.5:(.35+.65*a.m/reqN);if(a.m===reqN)s*=1.35}
      const meta=all[pDoc[pid]];let nm=0;pq.stems.forEach(t=>{if(meta.nameStems.has(t))nm++});if(nm)s*=1+.25*nm;
      list.push({pid,s,m:a.m});
    });
    list.sort((a,b)=>b.s-a.s);
    const needles=[...pq.phrases];if(pq.stems.length>1&&!pq.phrases.length)needles.push(pq.flat);
    return {list:list.slice(0,300),roots:[...roots],needles};
  }

  /* ---- meaning search over saved vectors ---- */
  semantic(qv,{docIdx=-1,k=60,floor=.25,rel=.12}={}){
    const v=this.vec;if(!v.n||!qv||qv.length!==v.dim)return [];
    const dim=v.dim,d=v.data,best=new Map();
    for(let c=0;c<v.n;c++){
      const di=v.cdoc[c];if((docIdx>=0&&di!==docIdx)||this.all[di].dead)continue;
      const o=c*dim;let s0=0,s1=0,s2=0,s3=0,j=0;
      for(;j+3<dim;j+=4){s0+=qv[j]*d[o+j];s1+=qv[j+1]*d[o+j+1];s2+=qv[j+2]*d[o+j+2];s3+=qv[j+3]*d[o+j+3]}
      for(;j<dim;j++)s0+=qv[j]*d[o+j];
      const s=(s0+s1+s2+s3)/127,pid=this.all[di].base+v.cpage[c]-1,cur=best.get(pid);if(!cur||s>cur.s)best.set(pid,{s,c});
    }
    const list=[];best.forEach((x,pid)=>list.push({pid,s:x.s,c:x.c}));list.sort((a,b)=>b.s-a.s);
    if(!list.length)return [];const top=list[0].s,min=Math.max(floor,top-rel);
    return list.filter(x=>x.s>=min).slice(0,k);
  }

  /** Keyword + meaning, fused with reciprocal rank fusion, grouped by document. */
  async search(q,{docId='all',kind='all',headOnly=false,extra=[],qvec=null,floor,rel,textOf}={}){
    let docIdx=-1;if(docId!=='all'){const m=this.byId.get(docId);if(!m)return null;docIdx=m.i}
    const kw=this.keyword(q,{docIdx,headOnly,extra});let kwList=kw?kw.list:[];
    if(textOf&&kw&&kw.needles.length&&kwList.length){
      const top=kwList.slice(0,40);
      await Promise.all(top.map(async r=>{const t=await textOf(this.all[this.pDoc[r.pid]],this.pNo[r.pid]);if(t){const lc=t.toLowerCase().replace(/\s+/g,' ');if(kw.needles.some(n=>lc.includes(n)))r.s*=1.5}}));
      kwList=kwList.slice().sort((a,b)=>b.s-a.s);
    }
    const sem=(qvec&&!headOnly)?this.semantic(qvec,{docIdx,floor,rel}):[];
    const fused=new Map();
    kwList.forEach((r,i)=>fused.set(r.pid,{pid:r.pid,s:1/(60+i),kw:true,sem:false,chunk:-1}));
    sem.forEach((r,i)=>{const w=1.1/(60+i),f=fused.get(r.pid);if(f){f.s+=w;f.sem=true;f.chunk=r.c}else fused.set(r.pid,{pid:r.pid,s:w,kw:false,sem:true,chunk:r.c})});
    let list=[...fused.values()].sort((a,b)=>b.s-a.s);
    const counts={},seenD=new Set();for(const r of list){const di=this.pDoc[r.pid];if(seenD.has(di))continue;seenD.add(di);const k=this.all[di].kind||'pdf';counts[k]=(counts[k]||0)+1}
    if(kind!=='all')list=list.filter(r=>(this.all[this.pDoc[r.pid]].kind||'pdf')===kind);
    if(!list.length)return {hits:[],counts,roots:kw?kw.roots:[],nPages:0,top:1,semUsed:sem.length>0};
    const by=new Map();
    for(const r of list){const di=this.pDoc[r.pid];let g=by.get(di);if(!g)by.set(di,g={doc:this.all[di],pages:[],score:0});g.pages.push({p:this.pNo[r.pid],s:r.s,kw:r.kw,sem:r.sem,chunk:r.chunk})}
    const hits=[...by.values()].map(g=>({...g,score:g.pages[0].s+.25*(g.pages[1]?g.pages[1].s:0)})).sort((a,b)=>b.score-a.score);
    return {hits,counts,roots:kw?kw.roots:[],nPages:list.length,top:hits[0].score,semUsed:sem.length>0};
  }
}
