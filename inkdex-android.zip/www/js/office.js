// Text extraction for every non-PDF format: Word, PowerPoint, Excel, OpenDocument, RTF, HTML, Markdown, CSV and plain text.
// Office files are ZIP archives of XML. This module reads them with the browser's own DecompressionStream, so nothing extra is downloaded.
import {extractPDF,tick} from './textproc.js';

export const KINDS=[
  {id:'pdf',  label:'PDF',        tag:'PDF', unit:'page'},
  {id:'word', label:'Word',       tag:'DOC', unit:'page'},
  {id:'slides',label:'PowerPoint',tag:'PPT', unit:'slide'},
  {id:'sheet',label:'Excel',      tag:'XLS', unit:'part'},
  {id:'text', label:'Text',       tag:'TXT', unit:'part'},
];
const EXT={pdf:'pdf',docx:'word',docm:'word',dotx:'word',odt:'word',rtf:'word',pptx:'slides',pptm:'slides',ppsx:'slides',odp:'slides',
  xlsx:'sheet',xlsm:'sheet',ods:'sheet',csv:'sheet',tsv:'sheet',txt:'text',md:'text',markdown:'text',json:'text',log:'text',html:'text',htm:'text',xml:'text'};
export const SUPPORTED_EXTS=Object.keys(EXT);
export const OLD_EXTS=['doc','ppt','xls'];
export const extOf=n=>{const m=/\.([a-z0-9]+)$/i.exec(n||'');return m?m[1].toLowerCase():''};
export const kindOf=n=>EXT[extOf(n)]||null;
export const kindInfo=k=>KINDS.find(x=>x.id===(k||'pdf'))||KINDS[0];
export const baseName=n=>(n||'').replace(/\.[a-z0-9]{1,8}$/i,'');
export const ACCEPT=SUPPORTED_EXTS.map(e=>'.'+e).join(',')+',application/pdf';
const MIME={pdf:'application/pdf',docx:'application/vnd.openxmlformats-officedocument.wordprocessingml.document',pptx:'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  xlsx:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',odt:'application/vnd.oasis.opendocument.text',odp:'application/vnd.oasis.opendocument.presentation',
  ods:'application/vnd.oasis.opendocument.spreadsheet',rtf:'application/rtf',csv:'text/csv',txt:'text/plain',md:'text/markdown',html:'text/html',htm:'text/html',json:'application/json',xml:'application/xml'};
export const mimeOf=n=>MIME[extOf(n)]||'application/octet-stream';

/* ---------- ZIP ---------- */
async function inflate(bytes){
  const ds=new DecompressionStream('deflate-raw');
  const out=new Response(new Blob([bytes]).stream().pipeThrough(ds));
  return new Uint8Array(await out.arrayBuffer());
}
export async function unzip(buf){
  const u=new Uint8Array(buf),dv=new DataView(u.buffer,u.byteOffset,u.byteLength);
  let e=-1;for(let i=u.length-22;i>=Math.max(0,u.length-66000);i--){if(dv.getUint32(i,true)===0x06054b50){e=i;break}}
  if(e<0)throw new Error('not a readable file (damaged or not an Office document)');
  const n=dv.getUint16(e+10,true);let p=dv.getUint32(e+16,true);
  const dec=new TextDecoder(),entries=new Map();
  for(let k=0;k<n;k++){
    if(dv.getUint32(p,true)!==0x02014b50)break;
    const method=dv.getUint16(p+10,true),csize=dv.getUint32(p+20,true),nl=dv.getUint16(p+28,true),xl=dv.getUint16(p+30,true),cl=dv.getUint16(p+32,true),off=dv.getUint32(p+42,true);
    entries.set(dec.decode(u.subarray(p+46,p+46+nl)),{method,csize,off});p+=46+nl+xl+cl;
  }
  return {
    names:[...entries.keys()],
    has:name=>entries.has(name),
    async text(name){
      const en=entries.get(name);if(!en)return null;
      const lo=en.off,start=lo+30+dv.getUint16(lo+26,true)+dv.getUint16(lo+28,true),raw=u.subarray(start,start+en.csize);
      const data=en.method===0?raw:en.method===8?await inflate(raw):null;
      if(!data)throw new Error('unsupported compression');
      return dec.decode(data);
    }
  };
}
const xml=s=>new DOMParser().parseFromString(s,'application/xml');
const byTag=(el,tag)=>[...el.getElementsByTagName(tag)];
const num=s=>+(/(\d+)/.exec(s)||[0,0])[1];

/* ---------- pagination: turn [{text,head:level|0,brk}] into pages ---------- */
function paginate(blocks,target=2600){
  const texts=[],heads=[];let cur=[],len=0;
  const flush=()=>{if(cur.length){texts.push(cur.join('\n'));cur=[];len=0}};
  for(const b of blocks){
    if(b.brk){flush();continue}
    const t=(b.text||'').replace(/[ \t ]+/g,' ').trim();if(!t)continue;
    if(b.head&&len>target*0.6)flush();
    if(len+t.length>target&&len>0)flush();
    if(b.head&&t.length<=140)heads.push({p:texts.length+1,t,l:Math.min(3,b.head)});
    cur.push(t);len+=t.length+1;
  }
  flush();
  if(!texts.length)texts.push('');
  return {texts,heads:heads.slice(0,400),scanned:texts[0]?[]:[1],n:texts.length};
}

/* ---------- Word (.docx) ---------- */
function wText(el){
  let s='';
  const walk=n=>{for(const c of n.childNodes){
    const nm=c.nodeName;
    if(nm==='w:t'||nm==='w:delText')s+=c.textContent;
    else if(nm==='w:tab')s+=' ';
    else if(nm==='w:br'||nm==='w:cr')s+=(c.getAttribute&&c.getAttribute('w:type')==='page')?'\f':'\n';
    else if(c.childNodes&&c.childNodes.length)walk(c);
  }};
  walk(el);return s;
}
async function docx(z){
  const doc=xml(await z.text('word/document.xml')),body=doc.getElementsByTagName('w:body')[0];if(!body)throw new Error('empty document');
  const blocks=[];
  for(const el of body.children){
    if(el.nodeName==='w:p'){
      const st=el.getElementsByTagName('w:pStyle')[0],sv=st?st.getAttribute('w:val')||'':'';
      const hm=/(?:heading|berschrift|titre|t[i\u00ed]tulo|kop)\s*(\d)/i.exec(sv);
      const head=/^title$/i.test(sv)?1:hm?Math.min(3,+hm[1]):0;
      const t=wText(el);
      if(el.getElementsByTagName('w:lastRenderedPageBreak').length&&blocks.length&&!head)blocks.push({brk:true});
      t.split('\f').forEach((part,i)=>{if(i>0)blocks.push({brk:true});blocks.push({text:part,head})});
    }else if(el.nodeName==='w:tbl'){
      for(const tr of byTag(el,'w:tr'))blocks.push({text:byTag(tr,'w:tc').map(tc=>wText(tc).replace(/\s+/g,' ').trim()).filter(Boolean).join(' | ')});
    }
  }
  // headers, footnotes are skipped on purpose: they repeat on every page
  return paginate(blocks);
}

/* ---------- PowerPoint (.pptx): one page per slide ---------- */
async function pptx(z){
  const slides=z.names.filter(n=>/^ppt\/slides\/slide\d+\.xml$/.test(n)).sort((a,b)=>num(a)-num(b));
  if(!slides.length)throw new Error('no slides found');
  const texts=[],heads=[];
  for(let i=0;i<slides.length;i++){
    const d=xml(await z.text(slides[i])),lines=[];let title='';
    for(const sp of byTag(d,'p:sp')){
      const ph=sp.getElementsByTagName('p:ph')[0],isTitle=ph&&/title/i.test(ph.getAttribute('type')||'');
      for(const p of byTag(sp,'a:p')){const t=byTag(p,'a:t').map(x=>x.textContent).join('').trim();if(t){lines.push(t);if(isTitle&&!title)title=t}}
    }
    for(const tbl of byTag(d,'a:tbl'))for(const tr of byTag(tbl,'a:tr'))lines.push(byTag(tr,'a:tc').map(tc=>byTag(tc,'a:t').map(x=>x.textContent).join('')).join(' | '));
    let notes=null;const relp=slides[i].replace('slides/','slides/_rels/')+'.rels';
    if(z.has(relp)){const rd=xml(await z.text(relp));for(const r of byTag(rd,'Relationship'))if(/notesSlide$/.test(r.getAttribute('Type')||''))notes='ppt/'+(r.getAttribute('Target')||'').replace(/^\.\.\//,'').replace(/^\/ppt\//,'')}
    if(notes&&z.has(notes)){const nd=xml(await z.text(notes));const nt=byTag(nd,'a:t').map(x=>x.textContent).join(' ').replace(/\s+/g,' ').trim();if(nt.length>3&&!/^\d+$/.test(nt))lines.push('Notes: '+nt)}
    if(!title&&lines[0]&&lines[0].length<90)title=lines[0];
    if(title)heads.push({p:i+1,t:title.slice(0,120),l:1});
    texts.push([...new Set(lines)].join('\n'));
    if(i%10===9)await tick();
  }
  return {texts,heads,scanned:texts.map((t,i)=>t.trim()?0:i+1).filter(Boolean),n:texts.length};
}

/* ---------- Excel (.xlsx): each sheet, split every 50 rows ---------- */
function colIdx(ref){let c=0;for(const ch of (ref||'').replace(/\d+/g,''))c=c*26+(ch.charCodeAt(0)-64);return c-1}
async function xlsx(z){
  const shared=[];
  if(z.has('xl/sharedStrings.xml')){const d=xml(await z.text('xl/sharedStrings.xml'));for(const si of byTag(d,'si'))shared.push(byTag(si,'t').map(t=>t.textContent).join(''))}
  const wb=xml(await z.text('xl/workbook.xml')),rels=z.has('xl/_rels/workbook.xml.rels')?xml(await z.text('xl/_rels/workbook.xml.rels')):null;
  const relMap=new Map();if(rels)for(const r of byTag(rels,'Relationship'))relMap.set(r.getAttribute('Id'),r.getAttribute('Target'));
  const sheets=byTag(wb,'sheet').map((s,i)=>{let t=relMap.get(s.getAttribute('r:id'))||`worksheets/sheet${i+1}.xml`;t=t.replace(/^\/?xl\//,'').replace(/^\//,'');return {name:s.getAttribute('name')||'Sheet '+(i+1),path:'xl/'+t}});
  const blocks=[];
  for(const sh of sheets){
    const raw=await z.text(sh.path);if(!raw)continue;
    const d=xml(raw);blocks.push({brk:true});blocks.push({text:sh.name,head:1});
    let rows=0;
    for(const row of byTag(d,'row')){
      const cells=[];
      for(const c of byTag(row,'c')){
        const t=c.getAttribute('t'),v=c.getElementsByTagName('v')[0];let s='';
        if(t==='s'&&v)s=shared[+v.textContent]||'';else if(t==='inlineStr')s=byTag(c,'t').map(x=>x.textContent).join('');else if(v)s=v.textContent;
        if(s!=='')cells[colIdx(c.getAttribute('r'))>=0?colIdx(c.getAttribute('r')):cells.length]=s;
      }
      const line=cells.filter(x=>x!==undefined&&x!=='').join(' | ');
      if(line){blocks.push({text:line});if(++rows%50===0)blocks.push({brk:true})}
    }
    await tick();
  }
  return paginate(blocks,3200);
}

/* ---------- OpenDocument (.odt .odp .ods) ---------- */
async function odf(z,kind){
  const d=xml(await z.text('content.xml'));
  const tx=el=>{let s='';const w=n=>{for(const c of n.childNodes){if(c.nodeType===3)s+=c.nodeValue;else if(c.nodeName==='text:s')s+=' ';else if(c.nodeName==='text:tab')s+=' ';else if(c.nodeName==='text:line-break')s+='\n';else w(c)}};w(el);return s};
  if(kind==='slides'){
    const pages=byTag(d,'draw:page'),texts=[],heads=[];
    pages.forEach((pg,i)=>{const lines=byTag(pg,'text:p').map(tx).map(s=>s.trim()).filter(Boolean);texts.push(lines.join('\n'));if(lines[0])heads.push({p:i+1,t:(pg.getAttribute('draw:name')&&!/^page\d+$/i.test(pg.getAttribute('draw:name'))?pg.getAttribute('draw:name'):lines[0]).slice(0,120),l:1})});
    return {texts:texts.length?texts:[''],heads,scanned:[],n:Math.max(1,texts.length)};
  }
  const blocks=[];
  if(kind==='sheet'){
    for(const t of byTag(d,'table:table')){blocks.push({brk:true});blocks.push({text:t.getAttribute('table:name')||'Sheet',head:1});let r=0;
      for(const row of byTag(t,'table:table-row')){const line=byTag(row,'table:table-cell').map(c=>byTag(c,'text:p').map(tx).join(' ').trim()).filter(Boolean).join(' | ');if(line){blocks.push({text:line});if(++r%50===0)blocks.push({brk:true})}}}
    return paginate(blocks,3200);
  }
  const bodyText=d.getElementsByTagName('office:text')[0]||d.documentElement;
  const walk=n=>{for(const c of n.children){
    if(c.nodeName==='text:h')blocks.push({text:tx(c),head:+(c.getAttribute('text:outline-level')||1)});
    else if(c.nodeName==='text:p')blocks.push({text:tx(c)});
    else if(c.nodeName==='table:table-row')blocks.push({text:byTag(c,'table:table-cell').map(x=>tx(x).trim()).filter(Boolean).join(' | ')});
    else walk(c);
  }};
  walk(bodyText);
  return paginate(blocks);
}

/* ---------- plain formats ---------- */
function decodeText(buf){
  const u=new Uint8Array(buf);
  if(u[0]===0xff&&u[1]===0xfe)return new TextDecoder('utf-16le').decode(u);
  if(u[0]===0xfe&&u[1]===0xff)return new TextDecoder('utf-16be').decode(u);
  try{return new TextDecoder('utf-8',{fatal:true}).decode(u)}catch(e){return new TextDecoder('windows-1252').decode(u)}
}
function rtfToText(s){
  // crude but dependable: drop groups we cannot show, convert escapes, strip control words
  s=s.replace(/\{\\\*[^{}]*(\{[^{}]*\}[^{}]*)*\}/g,'').replace(/\{\\(fonttbl|colortbl|stylesheet|info|pict)[\s\S]*?\}\s*\}/g,'');
  s=s.replace(/\\par[d]?\b ?/g,'\n').replace(/\\line\b ?/g,'\n').replace(/\\tab\b ?/g,' ').replace(/\\page\b ?/g,'\f');
  s=s.replace(/\\'([0-9a-f]{2})/gi,(_,h)=>String.fromCharCode(parseInt(h,16))).replace(/\\u(-?\d+)\??/g,(_,n)=>String.fromCharCode((+n+65536)%65536));
  s=s.replace(/\\[a-z]+-?\d* ?/gi,'').replace(/\\([{}\\])/g,'$1').replace(/[{}]/g,'');
  return s;
}
function plain(buf,ext){
  let s=decodeText(buf);const blocks=[];
  if(ext==='rtf')s=rtfToText(s);
  if(ext==='html'||ext==='htm'||ext==='xml'){
    const d=new DOMParser().parseFromString(s,ext==='xml'?'application/xml':'text/html');
    if(ext!=='xml'){d.querySelectorAll('script,style,noscript').forEach(x=>x.remove());
      const blk=d.body?d.body.querySelectorAll('h1,h2,h3,h4,p,li,td,th,pre,blockquote,div:not(:has(*))'):[];
      if(blk.length){for(const el of blk){const lv=/^H(\d)$/.exec(el.tagName);blocks.push({text:el.textContent,head:lv?Math.min(3,+lv[1]):0})}return paginate(blocks)}
      s=d.body?d.body.textContent:'';
    }else s=d.documentElement?d.documentElement.textContent:s;
  }
  if(ext==='csv'||ext==='tsv'){
    const sep=ext==='tsv'?'\t':(s.split('\n',5).join('').split(';').length>s.split('\n',5).join('').split(',').length?';':',');
    let r=0;for(const line of s.split(/\r?\n/)){if(!line.trim())continue;blocks.push({text:line.split(sep).map(x=>x.replace(/^"|"$/g,'').trim()).filter(Boolean).join(' | ')});if(++r%50===0)blocks.push({brk:true})}
    return paginate(blocks,3200);
  }
  for(const part of s.split('\f')){
    blocks.push({brk:true});
    for(const line of part.split(/\r?\n/)){
      const md=(ext==='md'||ext==='markdown')&&/^(#{1,6})\s+(.*)$/.exec(line);
      blocks.push(md?{text:md[2],head:Math.min(3,md[1].length)}:{text:line});
    }
  }
  return paginate(blocks);
}

/** Read any supported file. Returns {texts, heads, scanned, n}. */
export async function extractAny(file,worker){
  const ext=extOf(file.name),kind=kindOf(file.name);
  if(OLD_EXTS.includes(ext))throw new Error(`old .${ext} format: save it as .${ext}x and add it again`);
  if(!kind)throw new Error('file type not supported');
  if(kind==='pdf')return extractPDF(file,worker);
  const buf=await file.arrayBuffer();
  if(['docx','docm','dotx','pptx','pptm','ppsx','xlsx','xlsm','odt','odp','ods'].includes(ext)){
    const z=await unzip(buf);
    if(ext.startsWith('doc')||ext==='dotx')return docx(z);
    if(ext.startsWith('pp'))return pptx(z);
    if(ext.startsWith('xl'))return xlsx(z);
    return odf(z,kind);
  }
  return plain(buf,ext);
}
