// Runs the chat-brain (small language model) off the main thread.
import {pipeline,TextStreamer,InterruptableStoppingCriteria,env} from '../vendor/transformers.min.js';
env.allowLocalModels=false;env.allowRemoteModels=true;env.useBrowserCache=true;
env.backends.onnx.wasm.wasmPaths=new URL('../vendor/',import.meta.url).href;
env.backends.onnx.wasm.proxy=false;
let gen=null,stopper=null;
const send=m=>postMessage(m);
onmessage=async e=>{
  const m=e.data;
  try{
    if(m.type==='load'){
      if(gen){try{await gen.dispose()}catch(_){}gen=null}
      let device=m.device,dtype=m.dtype;
      const mk=(d,t)=>pipeline('text-generation',m.hf,{dtype:t,device:d,progress_callback:p=>send({type:'progress',p})});
      try{gen=await mk(device,dtype)}catch(err){if(device==='webgpu'&&m.fallbackDtype){device='wasm';dtype=m.fallbackDtype;gen=await mk(device,dtype)}else throw err}
      send({id:m.id,ok:true,device});
    }else if(m.type==='generate'){
      if(!gen)throw new Error('The chat brain is not loaded');
      stopper=new InterruptableStoppingCriteria();
      const streamer=new TextStreamer(gen.tokenizer,{skip_prompt:true,skip_special_tokens:true,callback_function:t=>send({type:'tok',id:m.id,t})});
      await gen(m.messages,{max_new_tokens:m.maxNew||400,do_sample:false,repetition_penalty:1.08,streamer,stopping_criteria:stopper});
      send({id:m.id,ok:true});
    }else if(m.type==='interrupt'){
      if(stopper)stopper.interrupt();
    }else if(m.type==='dispose'){
      if(gen){try{await gen.dispose()}catch(_){}gen=null}send({id:m.id,ok:true});
    }
  }catch(err){send({id:m.id,ok:false,error:String(err&&err.message||err)})}
};
