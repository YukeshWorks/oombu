// On-device AI: model catalog, downloads, and thin wrappers around the two workers.
export const EMBED_MODELS=[
  {id:'minilm',hf:'Xenova/all-MiniLM-L6-v2',name:'MiniLM',tag:'English, fastest',mb:23,dtype:'q8',qp:'',pp:'',floor:.28,rel:.12,note:'Smallest and quickest. Good for English notes and textbooks.'},
  {id:'bge',hf:'Xenova/bge-small-en-v1.5',name:'BGE Small',tag:'English, more accurate',mb:34,dtype:'q8',qp:'Represent this sentence for searching relevant passages: ',pp:'',floor:.5,rel:.1,note:'Better ranking than MiniLM at a similar speed.'},
  {id:'e5',hf:'Xenova/multilingual-e5-small',name:'E5 Small',tag:'100+ languages',mb:118,dtype:'q8',qp:'query: ',pp:'passage: ',floor:.74,rel:.05,note:'Use this if your PDFs include Tamil, Hindi or other languages.'}
];
export const CHAT_MODELS=[
  {id:'smol',hf:'onnx-community/SmolLM2-360M-Instruct',name:'SmolLM2 360M',tag:'Tiny and quick',mb:380,dtype:'q4f16',fallback:'q4',note:'Fastest. Short, simple answers.'},
  {id:'qwen05',hf:'onnx-community/Qwen2.5-0.5B-Instruct',name:'Qwen2.5 0.5B',tag:'Best starter',mb:500,dtype:'q4f16',fallback:'q4',note:'Good balance for a 6 GB phone.'},
  {id:'llama1b',hf:'onnx-community/Llama-3.2-1B-Instruct-q4f16',name:'Llama 3.2 1B',tag:'Clearer answers',mb:1000,dtype:'q4f16',fallback:'q4',note:'Slower, needs about 1.5 GB free memory.'},
  {id:'qwen15',hf:'onnx-community/Qwen2.5-1.5B-Instruct',name:'Qwen2.5 1.5B',tag:'Smartest here',mb:1300,dtype:'q4f16',fallback:'q4',note:'Best answers, slowest. Needs a recent phone GPU.'}
];
export const hasWebGPU=()=>!!navigator.gpu;

class Channel{
  constructor(url){this.url=url;this.w=null;this.pending=new Map();this.n=0;this.onprogress=null;this.ontok=null}
  spawn(){
    if(this.w)return;
    this.w=new Worker(new URL(this.url,import.meta.url),{type:'module'});
    this.w.onmessage=e=>{
      const m=e.data;
      if(m.type==='progress'){this.onprogress&&this.onprogress(m.p);return}
      if(m.type==='tok'){const p=this.pending.get(m.id);p&&p.ontok&&p.ontok(m.t);return}
      const p=this.pending.get(m.id);if(!p)return;this.pending.delete(m.id);m.ok?p.res(m):p.rej(new Error(m.error||'AI worker error'));
    };
    this.w.onerror=e=>{const err=new Error('The AI engine failed to start. '+(e.message||''));for(const p of this.pending.values())p.rej(err);this.pending.clear();this.w=null};
  }
  call(msg,transfer,ontok){this.spawn();return new Promise((res,rej)=>{const id=++this.n;this.pending.set(id,{res,rej,ontok});this.w.postMessage({...msg,id},transfer||[])})}
  kill(){if(this.w){this.w.terminate();this.w=null}for(const p of this.pending.values())p.rej(new Error('Stopped'));this.pending.clear()}
}

export class Embedder{
  constructor(){this.ch=new Channel('./embed-worker.js');this.model=null;this.device=null}
  set onprogress(f){this.ch.onprogress=f}
  get ready(){return !!this.model}
  async load(model,{device='wasm',local=null}={}){
    const r=await this.ch.call({type:'load',hf:model.hf,dtype:model.dtype,device,local});
    this.model=model;this.device=r.device;return r;
  }
  async embed(texts,kind){
    const pre=kind==='query'?this.model.qp:this.model.pp;
    const r=await this.ch.call({type:'embed',texts:pre?texts.map(t=>pre+t):texts});
    return {dim:r.dim,data:r.data};
  }
  async unload(){this.model=null;try{await this.ch.call({type:'dispose'})}catch(e){}}
}
export class Chat{
  constructor(){this.ch=new Channel('./llm-worker.js');this.model=null;this.device=null}
  set onprogress(f){this.ch.onprogress=f}
  get ready(){return !!this.model}
  async load(model){
    const device=hasWebGPU()?'webgpu':'wasm';
    const r=await this.ch.call({type:'load',hf:model.hf,dtype:device==='webgpu'?model.dtype:model.fallback,fallbackDtype:model.fallback,device});
    this.model=model;this.device=r.device;return r;
  }
  generate(messages,ontok,maxNew){return this.ch.call({type:'generate',messages,maxNew},[],ontok)}
  stop(){if(this.ch.w)this.ch.w.postMessage({type:'interrupt'})}
  async unload(){this.model=null;try{await this.ch.call({type:'dispose'})}catch(e){}}
}

/* ---- download bookkeeping (transformers.js stores files in the Cache API) ---- */
const CACHE='transformers-cache';
export async function cachedFiles(hf){
  try{const c=await caches.open(CACHE);const ks=await c.keys();return ks.filter(r=>r.url.includes('/'+hf+'/')).length}catch(e){return 0}
}
export async function removeCached(hf){
  try{const c=await caches.open(CACHE);const ks=await c.keys();await Promise.all(ks.filter(r=>r.url.includes('/'+hf+'/')).map(r=>c.delete(r)))}catch(e){}
}
/** Aggregates transformers.js progress events into one 0..1 value. */
export function progressTracker(cb){
  const files=new Map();
  return p=>{
    if(!p)return;
    if(p.status==='progress'||p.status==='download'||p.status==='initiate'){
      const f=files.get(p.file)||{loaded:0,total:0};
      if(p.total)f.total=p.total;if(p.loaded!=null)f.loaded=p.loaded;files.set(p.file,f);
    }else if(p.status==='done'){const f=files.get(p.file);if(f)f.loaded=f.total}
    let l=0,t=0;files.forEach(f=>{l+=f.loaded;t+=f.total});
    cb(t?l/t:0,l,t,p.status);
  };
}
export async function storageInfo(){
  try{const e=await navigator.storage.estimate();const persisted=navigator.storage.persisted?await navigator.storage.persisted():false;return {usage:e.usage||0,quota:e.quota||0,persisted}}catch(e){return {usage:0,quota:0,persisted:false}}
}
