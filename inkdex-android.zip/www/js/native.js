// Bridge to the Android APK's PdfScan plugin. In a normal browser every function falls back to web behaviour.
import {mimeOf} from './office.js';
const cap=()=>window.Capacitor;
export const isNative=()=>{const c=cap();return !!(c&&(c.isNativePlatform?c.isNativePlatform():c.getPlatform&&c.getPlatform()!=='web'))};
function call(method,opts={}){
  const c=cap();if(!c)return Promise.reject(new Error('not native'));
  const p=c.Plugins&&c.Plugins.PdfScan;
  if(p&&typeof p[method]==='function')return p[method](opts);
  if(c.nativePromise)return c.nativePromise('PdfScan',method,opts);
  return Promise.reject(new Error('PdfScan plugin missing'));
}
export const hasAccess=async()=>{try{return !!(await call('hasAccess')).granted}catch(e){return false}};
export const requestAccess=()=>call('requestAccess');
export const keepAwake=on=>{if(isNative())call('keepAwake',{on:!!on}).catch(()=>{})};
/** Scan the whole phone storage for supported documents. Returns [{path,name,size,modified}] */
export async function scan(){const r=await call('scan');return r.files||[]}
const fileUrl=path=>{const c=cap();return c&&c.convertFileSrc?c.convertFileSrc('file://'+path):location.origin+'/_capacitor_file_'+path};
/** Read a file from phone storage. Tries the WebView file server first, then the plugin. */
export async function readPath(path){
  try{const r=await fetch(fileUrl(path));if(r.ok){const b=await r.arrayBuffer();if(b.byteLength)return b}}catch(e){}
  const {data}=await call('read',{path});const bin=atob(data),u=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)u[i]=bin.charCodeAt(i);return u.buffer;
}
/** A lazy File-like object: bytes are only read when the indexer gets to it. */
export const lazyFile=f=>({name:f.name,size:f.size,lastModified:f.modified,type:mimeOf(f.name),nativePath:f.path,arrayBuffer:()=>readPath(f.path)});
const b64=async blob=>{const u=new Uint8Array(await blob.arrayBuffer());let s='';for(let i=0;i<u.length;i+=0x8000)s+=String.fromCharCode.apply(null,u.subarray(i,i+0x8000));return btoa(s)};
/** Share a PDF. path = file on phone storage, or blob = stored copy. Returns 'shared' | 'downloaded' | 'cancelled'. */
export async function sharePdf({path,blob,name}){
  if(isNative()){
    if(path){await call('share',{path,name});return 'shared'}
    if(blob){await call('shareData',{name,data:await b64(blob)});return 'shared'}
    throw new Error('No file to share');
  }
  if(!blob)throw new Error('The original file is not stored on this device');
  const file=new File([blob],name,{type:mimeOf(name)});
  if(navigator.canShare&&navigator.canShare({files:[file]})){
    try{await navigator.share({files:[file],title:name});return 'shared'}catch(e){if(e&&e.name==='AbortError')return 'cancelled';throw e}
  }
  const a=document.createElement('a');a.href=URL.createObjectURL(file);a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),4000);return 'downloaded';
}
export async function openWith({path,blob,name}){
  if(isNative()){if(path)return call('openWith',{path});if(blob)return call('openData',{name,data:await b64(blob)})}
  if(blob){window.open(URL.createObjectURL(blob),'_blank')}
}
