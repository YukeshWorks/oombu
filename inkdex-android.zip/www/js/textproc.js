// Text helpers shared by the app: tokenising, stemming, PDF line/heading detection, highlighting.
export const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export const fmtSize=b=>b>=1073741824?(b/1073741824).toFixed(2)+' GB':b>=1048576?(b/1048576).toFixed(1)+' MB':Math.max(1,Math.round(b/1024))+' KB';
export const sleep=ms=>new Promise(r=>setTimeout(r,ms));
export const tick=()=>new Promise(r=>setTimeout(r,0));

export const STOP=new Set('a an the and or of to in on for with is are was were be been it its this that these those as at by from into than then so such not no can will would should could may might has have had do does did i you we they he she them his her our your their what which who whom how when where why also about over under between within without per via if but like used use using include includes including typically often many much more most other each both some'.split(' '));
export const words=t=>(t.toLowerCase().match(/[\p{L}\p{N}]+/gu)||[]);
export function stem(w){
  if(w.length<=3||/\d/.test(w))return w;
  if(w.endsWith('ies')&&w.length>4)w=w.slice(0,-3)+'y';
  else if(w.endsWith('sses'))w=w.slice(0,-2);
  else if(w.endsWith('ing')&&w.length>5)w=w.slice(0,-3);
  else if(w.endsWith('ed')&&w.length>4)w=w.slice(0,-2);
  else if(w.endsWith('es')&&w.length>4)w=w.slice(0,-2);
  else if(w.endsWith('s')&&!/(ss|us|is)$/.test(w))w=w.slice(0,-1);
  if(w.length>4&&w.endsWith('e'))w=w.slice(0,-1);
  if(w.length>3&&w.endsWith('y'))w=w.slice(0,-1)+'i';
  return w;
}
export const SURF=new Map(); // stem -> shortest surface form seen (for showing topics)
export function indexTokens(text){
  const out=[];
  for(const w of words(text)){
    if(STOP.has(w)||w.length<2)continue;
    const s=stem(w); out.push(s);
    const cur=SURF.get(s); if(!cur||w.length<cur.length)SURF.set(s,w);
  }
  return out;
}
export const rootOf=s=>s.endsWith('i')&&s.length>3?s.slice(0,-1):s;
export function lev(a,b,max){
  if(a===b)return 0; const m=a.length,n=b.length; if(Math.abs(m-n)>max)return max+1;
  let prev=Array.from({length:n+1},(_,j)=>j);
  for(let i=1;i<=m;i++){const cur=[i];let rm=i;for(let j=1;j<=n;j++){const v=Math.min(prev[j]+1,cur[j-1]+1,prev[j-1]+(a[i-1]===b[j-1]?0:1));cur[j]=v;if(v<rm)rm=v}if(rm>max)return max+1;prev=cur}
  return prev[n];
}

/** Build the saved keyword-index record for one document. post = flat pairs [termId, packed]; packed = page0<<11 | min(bodyTf,255)<<3 | min(headingTf,7) */
export function analyzeDoc(texts,heads){
  const hb=new Map(); heads.forEach(h=>{if(!hb.has(h.p))hb.set(h.p,[]);hb.get(h.p).push(h.t)});
  const local=new Map(),terms=[],out=[],lens=new Uint32Array(texts.length);
  texts.forEach((txt,pi)=>{
    const b=new Map(),h=new Map(); const bt=indexTokens(txt); lens[pi]=bt.length;
    bt.forEach(t=>b.set(t,(b.get(t)||0)+1));
    const ht=hb.get(pi+1); if(ht)indexTokens(ht.join(' ')).forEach(t=>h.set(t,(h.get(t)||0)+1));
    const keys=new Set([...b.keys(),...h.keys()]);
    for(const t of keys){let id=local.get(t);if(id===undefined){id=terms.length;local.set(t,id);terms.push(t)}
      out.push(id,((pi<<11)|(Math.min(b.get(t)||0,255)<<3)|Math.min(h.get(t)||0,7))>>>0)}
  });
  return {terms,post:Uint32Array.from(out),lens};
}
export function topTopics(idx,heads,nPages){ // quick doc topics from its own index record (tf x rarity inside the doc)
  const sc=new Map(),{terms,post}=idx,df=new Map();
  for(let k=0;k<post.length;k+=2){const t=post[k],pk=post[k+1];sc.set(t,(sc.get(t)||0)+((pk>>>3)&255)+3*(pk&7));df.set(t,(df.get(t)||0)+1)}
  const arr=[];sc.forEach((c,t)=>{const w=terms[t];if(w.length<4||/\d/.test(w))return;arr.push([w,c*Math.log(1+nPages/(df.get(t)||1))])});
  return arr.sort((a,b)=>b[1]-a[1]).slice(0,10).map(([w])=>SURF.get(w)||w);
}

/* ---------- PDF text -> lines -> headings ---------- */
export function pageLines(items){
  const lines=[];let cur=null;
  for(const it of items){
    if(typeof it.str!=='string')continue;
    const x=it.transform[4],y=it.transform[5],h=Math.hypot(it.transform[2],it.transform[3])||it.height||10;
    if(!it.str.trim()&&!cur)continue;
    if(cur&&Math.abs(y-cur.y)<=Math.max(2,h*.45)){
      const gap=x-cur.endX;if(it.str&&!cur.text.endsWith(' ')&&!it.str.startsWith(' ')&&gap>h*.12)cur.text+=' ';
      cur.text+=it.str;cur.endX=x+(it.width||0);cur.h=Math.max(cur.h,h);
    }else{if(cur)lines.push(cur);cur={text:it.str,y,h,endX:x+(it.width||0)}}
  }
  if(cur)lines.push(cur);
  return lines.map(l=>({text:l.text.replace(/\s+/g,' ').trim(),h:Math.round(l.h*2)/2})).filter(l=>l.text);
}
export function detectHeadings(pagesLines){
  const freq=new Map();let total=0;
  pagesLines.forEach(ls=>ls.forEach(l=>{freq.set(l.h,(freq.get(l.h)||0)+l.text.length);total+=l.text.length}));
  if(!total)return [];
  let body=0,best=-1;freq.forEach((c,h)=>{if(c>best){best=c;body=h}});
  const raw=[];
  pagesLines.forEach((ls,pi)=>ls.forEach(l=>{
    const t=l.text,n=t.split(' ').length;if(t.length<3||t.length>110||n>16||/^\d+$/.test(t))return;
    const bigger=l.h>=body*1.18;
    const numbered=/^((\d+(\.\d+)*[.)]?)|chapter|section|unit|module|part)\s+\S/i.test(t)&&l.h>=body*1.04&&t.length<=90&&!/[.,;]$/.test(t);
    const caps=t.length>=4&&t.length<=70&&t===t.toUpperCase()&&/[A-Z]{3}/.test(t)&&l.h>=body;
    if(bigger||numbered||caps)raw.push({p:pi+1,t,h:l.h});
  }));
  const merged=[];for(const r of raw){const L=merged[merged.length-1];if(L&&L.p===r.p&&L.h===r.h&&L.t.length+r.t.length<120)L.t+=' '+r.t;else merged.push({...r})}
  const sizes=[...new Set(merged.map(m=>m.h))].sort((a,b)=>b-a);
  return merged.slice(0,400).map(m=>({p:m.p,t:m.t,l:Math.min(3,sizes.indexOf(m.h)+1)}));
}
export async function extractPDF(file,worker,onProg){
  const buf=await file.arrayBuffer();
  const pdf=await pdfjsLib.getDocument({data:new Uint8Array(buf),worker,isEvalSupported:false}).promise;
  const texts=[],lines=[],scanned=[];
  try{
    for(let p=1;p<=pdf.numPages;p++){
      const page=await pdf.getPage(p);const tc=await page.getTextContent();
      const ls=pageLines(tc.items);lines.push(ls);const t=ls.map(l=>l.text).join('\n');texts.push(t);
      if(t.replace(/\s/g,'').length<12)scanned.push(p);
      page.cleanup();onProg&&onProg(p/pdf.numPages);if(p%8===0)await tick();
    }
  }finally{try{await pdf.destroy()}catch(e){}}
  return {texts,heads:detectHeadings(lines),scanned,n:texts.length};
}

/* ---------- highlighting & snippets ---------- */
export function hiRegex(roots){const r=roots.filter(x=>x&&x.length>=2).sort((a,b)=>b.length-a.length).map(x=>x.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'));return r.length?new RegExp('(?<![\\p{L}\\p{N}])(?:'+r.join('|')+')[\\p{L}\\p{N}]*','giu'):null}
export function hiHTML(raw,re){
  if(!re)return esc(raw);
  const r=new RegExp(re.source,'giu');let out='',last=0,m;
  while((m=r.exec(raw))){if(m[0]==='')break;out+=esc(raw.slice(last,m.index))+'<mark>'+esc(m[0])+'</mark>';last=m.index+m[0].length}
  return out+esc(raw.slice(last));
}
export const clean=t=>t.replace(/\s+/g,' ').trim();
export function snippet(text,re,len=230){
  text=clean(text);if(!re)return esc(text.slice(0,len)+(text.length>len?' …':''));
  const pos=[];let m;const r=new RegExp(re.source,'giu');while((m=r.exec(text))&&pos.length<200){if(m[0]==='')break;pos.push([m.index,m[0].toLowerCase().slice(0,3)])}
  if(!pos.length)return esc(text.slice(0,len)+(text.length>len?' …':''));
  let at=0,bestN=-1;for(const [i] of pos){const set=new Set(pos.filter(([j])=>j>=i-40&&j<=i+len-60).map(x=>x[1]));if(set.size>bestN){bestN=set.size;at=i}}
  let s=Math.max(0,at-60);if(s>0){const sp=text.indexOf(' ',s);if(sp>-1&&sp<at)s=sp+1}
  let e=Math.min(text.length,s+len);if(e<text.length){const sp=text.lastIndexOf(' ',e);if(sp>s+60)e=sp}
  return (s>0?'… ':'')+hiHTML(text.slice(s,e),re)+(e<text.length?' …':'');
}
export function sectionOf(doc,p){let t='';for(const h of doc.heads){if(h.p<=p)t=h.t;else break}return t}
