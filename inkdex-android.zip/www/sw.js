// Service worker: makes the app open instantly and work with no internet after the first visit.
const VERSION='inkdex-v3';
const SHELL=['./','index.html','css/app.css','js/main.js','js/native.js','js/office.js','js/engine.js','js/store.js','js/textproc.js','js/indexer.js','js/ai.js','js/embed-worker.js','js/llm-worker.js','vendor/pdf.min.js','vendor/pdf.worker.min.js','vendor/transformers.min.js','manifest.webmanifest','icons/icon-192.png','icons/icon-512.png'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(VERSION).then(c=>c.addAll(SHELL)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k.startsWith('inkdex-')&&k!==VERSION).map(k=>caches.delete(k)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{
  const r=e.request;if(r.method!=='GET')return;
  const u=new URL(r.url);
  if(u.origin!==location.origin)return;               // model files from huggingface are cached by the AI library itself
  if(u.pathname.includes('/models/'))return;           // local test models are never cached
  e.respondWith((async()=>{
    const c=await caches.open(VERSION);
    const hit=await c.match(r,{ignoreSearch:r.mode==='navigate'});
    const net=fetch(r).then(res=>{if(res&&res.ok&&res.status===200)c.put(r,res.clone());return res}).catch(()=>null);
    if(hit){e.waitUntil(net);return hit}                // cached copy now, refresh in the background
    const res=await net;if(res)return res;
    if(r.mode==='navigate'){const idx=await c.match('index.html');if(idx)return idx}
    return new Response('Offline',{status:503});
  })());
});
