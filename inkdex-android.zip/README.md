# Inkdex — search your documents by what is inside them

Offline document search for Android: PDF, Word (.docx/.odt/.rtf), PowerPoint (.pptx/.odp), Excel (.xlsx/.ods/.csv) and text files. Keyword + on-device AI meaning search, category tabs, one-tap scan of every document on the phone, file dates, share and "open with".

Old binary .doc/.ppt/.xls files are not supported; save them as .docx/.pptx/.xlsx.

## Get the APK (no computer needed)
1. Push this folder to a GitHub repo (branch `main`).
2. GitHub builds it automatically (Actions tab, about 5–8 minutes).
3. Open the repo's **Releases** page on your phone and download `inkdex.apk`, then install it (allow "Install unknown apps" for your browser).

## Build on a computer instead
```
npm ci
npx cap sync android
cd android && ./gradlew assembleRelease
# android/app/build/outputs/apk/release/app-release.apk
```
Needs Node 22, JDK 21 and the Android SDK (Android Studio installs it).

## Notes
- The web app lives in `www/`. After editing it, run `npx cap sync android` before building.
- "Find all PDFs on phone" uses Android's **All files access** permission. That is fine for a sideloaded app, but Google Play would require a justification.
- Every build is signed with `android/app/inkdex.keystore`, so new versions install over old ones and keep your library. Keep that file; anyone with it could sign an update, so make the repo private if that matters to you.
